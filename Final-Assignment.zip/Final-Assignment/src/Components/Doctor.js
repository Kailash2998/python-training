import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

//show doctor dashboard
const Doctor = () => {
  const [patientData, patientDataChange] = useState(null);
  const navigate = useNavigate();

  //function to navigate to the appointment detail page
  const LoadDetail = (id) => {
    navigate("/AppointmentDetails/" + id);
  };

  //function to navigate to the appointment detail page
  const LoadEdit = (id) => {
    navigate("/AppointmentEdit/" + id);
  };

  useEffect(() => {
    fetch("http://localhost:3000/appointment")
      .then((res) => {
        return res.json();
      })
      .then((resp) => {
        patientDataChange(resp);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, []);
  return (
    <div className="container">
      <div className="card outside">
        <div className="card-title">
          <h2>Appointment List</h2>
        </div>
        <div className="card-body">
          <Link to="/" className="btn btn-danger butt">
            Logout
          </Link>

          <table className="table table-bordered">
            <thead className="bg-dark text-white">
              <tr>
                <td>ID</td>
                <td>Name</td>
                <td>Age</td>
                <td>Phone</td>
                <td>Date</td>
                <td>Time</td>
                <td>Notes</td>
                <td>Action</td>
              </tr>
            </thead>
            <tbody>
              {patientData &&
                patientData.map((item) => (
                  <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.name}</td>
                    <td>{item.age}</td>
                    <td>{item.phone}</td>
                    <td>{item.date}</td>
                    <td>{item.time}</td>
                    <td>{item.notes}</td>
                    <td>
                      <a
                        onClick={() => {
                          LoadEdit(item.id);
                        }}
                        className="btn btn-success upper "
                      >
                        Edit
                      </a>
                      <a
                        onClick={() => {
                          LoadDetail(item.id);
                        }}
                        className="btn btn-primary"
                      >
                        Details
                      </a>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Doctor;
