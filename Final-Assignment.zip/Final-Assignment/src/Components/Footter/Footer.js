import React from 'react'
import "./Footer.css";
class Footer extends React.Component {
  render() {
      return (
          <footer className="main-footer fixed-bottom">
                  <p>Sanjeevan Hospital Karve Road Pune , Maharashtra 411004.</p>
          </footer>
      )
  }
}

export default Footer;