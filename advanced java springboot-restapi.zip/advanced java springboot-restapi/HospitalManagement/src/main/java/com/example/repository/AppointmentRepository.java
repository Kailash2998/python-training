package com.example.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

//src/main/java/com/yourcompany/hospital/repository/AppointmentRepository.java

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.entity.Appointment;
import com.example.entity.AppointmentStatus;
import com.example.entity.User;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
	long countByStatus(AppointmentStatus status);

	List<Appointment> findByPatientEmail(String patientEmail);

//	@Query("SELECT a.appointmentTime FROM Appointment a WHERE a.appointmentDate = :date")
//	List<String> findBookedTimeSlotsByDate(LocalDate date);

	List<Appointment> findByDoctor(User doctor);

	long countByDoctor(User doctor);

	long countByDoctorAndStatus(User doctor, AppointmentStatus status);

	@Query("SELECT a.appointmentTime FROM Appointment a WHERE a.appointmentDate = :date AND a.doctor.id = :doctorId")
	List<String> findBookedTimeSlotsByDateAndDoctor(@Param("date") LocalDate date, @Param("doctorId") Long doctorId);
	
	@Query("SELECT COUNT(u) FROM Appointment u WHERE u.gender = :gender")
	Long countByGender(@Param("gender") String gender);
}
