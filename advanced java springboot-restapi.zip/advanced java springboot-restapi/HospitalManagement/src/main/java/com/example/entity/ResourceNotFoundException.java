package com.example.entity;

public class ResourceNotFoundException  extends RuntimeException  {

}
