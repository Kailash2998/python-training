package com.example.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

import com.example.entity.Appointment;
import com.opencsv.CSVWriter;

public class CsvUtils {
	public static byte[] generateCsvData(List<Appointment> appointments) {
		try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
				CSVWriter csvWriter = new CSVWriter(new OutputStreamWriter(baos))) {
			String[] header = { "Appointment ID", "Patient Name", "Gender", "Blood Group", "Date", "Time", "Reason",
					"Address", "Medical Prescription" };
			csvWriter.writeNext(header);
			for (Appointment appointment : appointments) {
				String[] rowData = { String.valueOf(appointment.getId()), appointment.getPatientName(),
						appointment.getGender(), appointment.getBloodGroup(),
						String.valueOf(appointment.getAppointmentDate()),
						String.valueOf(appointment.getAppointmentTime()), appointment.getReason(),
						appointment.getAddress(), appointment.getMedicalPrescription() };
				csvWriter.writeNext(rowData);
			}
			csvWriter.flush();
			return baos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
			return new byte[0];
		}
	}
}
