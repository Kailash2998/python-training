package com.example.controller;

//InvoiceController.java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.service.InvoiceService;
import com.itextpdf.text.DocumentException;

@Controller
public class InvoiceController {

	@Autowired
	private InvoiceService invoiceService;

	@GetMapping("/downloadInvoice/appointment/{appointmentId}")
	public ResponseEntity<byte[]> downloadInvoice(@PathVariable Long appointmentId) {
		try {
			byte[] pdfBytes = invoiceService.generateInvoiceByAppointment(appointmentId);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_PDF);
			headers.setContentDispositionFormData("attachment", "invoice_appointment_" + appointmentId + ".pdf");

			return new ResponseEntity<>(pdfBytes, headers, 200);
		} catch (DocumentException e) {
			e.printStackTrace();
			return ResponseEntity.status(500).body(null);
		}
	}
}
