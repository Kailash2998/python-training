package com.example.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.entity.Appointment;
import com.example.entity.AppointmentStatus;
import com.example.entity.User;
import com.example.service.AppointmentService;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AppointmentService appointmentService;

	@Autowired
	private UserService userService;

	@GetMapping("/profile")
	public String profilee(Model model) {
		List<User> users = userService.getAllUsers();
		long userCount = userService.countAllUsers();
		long totalDoctors = userService.countDoctors();
		long totalPatients = userService.countPatients();
		long totalAppointments = appointmentService.getTotalAppointmentsCount();

		model.addAttribute("totalDoctors", totalDoctors);
		model.addAttribute("totalPatients", totalPatients);
		model.addAttribute("users", users);
		model.addAttribute("userCount", userCount);
		model.addAttribute("totalAppointments", totalAppointments);

		long approvedAppointmentsCount = appointmentService.getApprovedAppointmentsCount();
		long deniedAppointmentsCount = appointmentService.getDeniedAppointmentsCount();
		model.addAttribute("approvedAppointmentsCount", approvedAppointmentsCount);
		model.addAttribute("deniedAppointmentsCount", deniedAppointmentsCount);

		long femalePatientsCount = appointmentService.countFemalePatients();
		long malePatientsCount = appointmentService.countMalePatients();
		model.addAttribute("femalePatientsCount", femalePatientsCount);
		model.addAttribute("malePatientsCount", malePatientsCount);
		return "admin-profile";
	}

	@GetMapping("/patientList")
	public String patientList(Model model) {
		List<Appointment> appointments = appointmentService.getAllAppointments();
		model.addAttribute("appointments", appointments);
		return "patientList";
	}

	@GetMapping("/view/{id}")
	public String showViewForm(@PathVariable("id") Long id, Model model) {
		Appointment appointment = appointmentService.getAppointmentById(id);
		model.addAttribute("appointment", appointment);

		return "viewAppointmentAdmin";
	}

	@GetMapping("/edit/{id}")
	public String showEditFormm(@PathVariable("id") Long id, Model model) {
		System.out.println("inside edit form");
		Appointment appointment = appointmentService.getAppointmentById(id);
		model.addAttribute("appointment", appointment);
		// Add the list of doctors to the model
		System.out.println(appointment);
		System.out.println(appointment.getDoctor().getFirstname());
		return "editAppointmentFormAdmin";
	}

	@PostMapping("/edit/{id}")
	public String updateAppointment(@PathVariable("id") Long id,
			@ModelAttribute("appointment") Appointment updatedAppointment) {
		appointmentService.updateAppointment(id, updatedAppointment);
		return "redirect:/admin/patientList";
	}

	@GetMapping("/delete/{id}")
	public String deleteAppointmentt(@PathVariable("id") Long id) {
		System.out.println("inside delete");
		appointmentService.deleteAppointment(id);
		return "redirect:/admin/patientList";
	}

	@GetMapping("/doctorList")
	public String doctorList(Model model) {
		List<User> entries = userService.getAllUsers(); // Assuming you have a method to retrieve all users
		model.addAttribute("entries", entries);
		return "doctorList";
	}

	// delete doctorlist record
	@GetMapping("/deletee/{id}")
	public String deleteuserrr(@PathVariable("id") Integer id) {
		System.out.println("inside doctors delete");
		userService.deleteUser(id);
		return "redirect:/admin/doctorList";
	}

	@GetMapping("/editt/{id}")
	public String showEditForm(@PathVariable("id") Long id, Model model) {
		User user = userService.getUserById(id);
		model.addAttribute("user", user);
		return "editUserForm"; // Update to your actual template name
	}

	@PostMapping("/edits/{id}")
	public String updateUserData(@PathVariable("id") Long id, @ModelAttribute("user") User updatedUser) {
		userService.updateUser(id, updatedUser);
		return "redirect:/admin/doctorList"; // Redirect to the user list after editing
	}

	@GetMapping("/vieww/{id}")
	public String showVieeUser(@PathVariable("id") Long id, Model model) {
		User user = userService.getUserById(id);
		model.addAttribute("user", user);
		return "viewUser";
	}

	@GetMapping("/addAppointment")
	public String showAddAppointmentForm(Model model) {
		model.addAttribute("appointment", new Appointment());
		LocalDate currentDate = LocalDate.now();

		// Replace 1L with the actual ID of the selected doctor
		Long selectedDoctorId = 1L; // You should retrieve this from your session or model

		List<String> availableTimeSlots = appointmentService.findAvailableTimeSlots(currentDate, selectedDoctorId);
		model.addAttribute("availableTimeSlots", availableTimeSlots);

		return "addAppointmentAdmin";
	}

	@PostMapping("/addAppointment")
	public String addAppointment(@ModelAttribute("appointment") Appointment appointment) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String userEmail = authentication.getName();
		appointment.setPatientEmail(userEmail);
		appointment.setStatus(AppointmentStatus.PENDING);
		System.out.println(appointment);
		appointmentService.saveAppointment(appointment);
		return "redirect:/admin/profile";
	}

	@GetMapping("/getAvailableTimeSlots")
	@ResponseBody
	public List<String> getAvailableTimeSlots(@RequestParam("selectedDate") String selectedDate,
			@RequestParam("selectedDoctorId") Long selectedDoctorId) {
		LocalDate date = LocalDate.parse(selectedDate);
		return appointmentService.findAvailableTimeSlots(date, selectedDoctorId);
	}

	@GetMapping("/getDoctors")
	@ResponseBody
	public List<User> getDoctors() {
		return userService.getDoctors(); // Implement this method in your UserService
	}

	@GetMapping("/addPatientDoctor")
	public String register() {
		return "register";
	}

	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute User user, HttpSession session, Model m) {
		if (userService.emailExists(user.getEmail())) {
			session.setAttribute("msg", "Email already exists. Please use a different email.");
			return "redirect:/register";
		} else {
			User u = userService.saveUser(user);
			if (u != null) {
				session.setAttribute("msg", "Register Successfully !!!");
			} else {
				session.setAttribute("msg", "Something went wrong on the server !!!");
			}
		}
		return "redirect:/admin/profile";
	}
}
