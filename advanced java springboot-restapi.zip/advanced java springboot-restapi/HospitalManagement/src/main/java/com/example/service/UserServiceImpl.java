package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.example.entity.Appointment;
import com.example.entity.User;
import com.example.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Override
	public User saveUser(User user) {
		String password = passwordEncoder.encode(user.getPassword());
		user.setPassword(password);
//		user.setRole("ROLE_PATIENT");
		User newuser = userRepository.save(user);
		return newuser;
	}

	@Override
	public void removeSessionMessage() {
		HttpSession session = ((ServletRequestAttributes) (RequestContextHolder.getRequestAttributes())).getRequest()
				.getSession();
		session.removeAttribute("msg");
	}

	@Override
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public boolean emailExists(String email) {
		return userRepository.existsByEmail(email);
	}

	@Override
	public List<User> getDoctors() {
		return userRepository.findByRole("ROLE_DOCTOR");
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public void deleteUser(Integer id) {

		userRepository.deleteById(id);
	}

	@Override
	public User getUserById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id);
	}

	@Override
	public void updateUser(Long id, User updatedUser) {
		User existingUser = userRepository.findById(id);
		if (existingUser != null) {
			// Update user details
			existingUser.setFirstname(updatedUser.getFirstname());
			existingUser.setLastname(updatedUser.getLastname());
			existingUser.setMobileNo(updatedUser.getMobileNo());
			existingUser.setCity(updatedUser.getCity());
			existingUser.setEmail(updatedUser.getEmail());
			existingUser.setRegistrationDate(updatedUser.getRegistrationDate());
			existingUser.setRole(updatedUser.getRole());
			// Update other fields as needed

			// Save the updated user to the database
			userRepository.save(existingUser);
		}
	}

	@Override
	public long countAllUsers() {
		return userRepository.count();
	}

	@Override
	public long countDoctors() {
		return userRepository.countByRole("ROLE_DOCTOR");
	}

	@Override
	public long countPatients() {
		return userRepository.countByRoleNot("ROLE_PATIENT");
	}

	
}
