package com.example.entity;

public enum AppointmentStatus {
	PENDING, APPROVED, DENIED
}
