package com.example.service;

import java.util.List;

import com.example.entity.User;

public interface UserService {
	public User saveUser(User user);

	public void removeSessionMessage();

	User findByEmail(String email);

	boolean emailExists(String email);

	List<User> getDoctors();

	List<User> getAllUsers();

	void deleteUser(Integer id);

	User getUserById(Long id);

	void updateUser(Long id, User updatedUser);

	long countAllUsers();

	long countDoctors();

	long countPatients();
	
	
}
