package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Appointment;
import com.example.entity.AppointmentStatus;
import com.example.entity.User;
import com.example.service.AppointmentService;
import com.example.service.UserService;
import com.example.util.CsvUtils;

import jakarta.servlet.http.HttpServletRequest;

import java.security.Principal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Controller
@RequestMapping("/appointments")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@Autowired
	private UserService userService;

	@GetMapping
	public String getAllAppointments(Model model, Principal principal) {
		String userEmail = principal.getName();
		User patient = userService.findByEmail(userEmail);
		List<Appointment> appointments = appointmentService.getAppointmentsByPatientEmail(userEmail);
		model.addAttribute("appointments", appointments);
		return "appointmentList";
	}

	@GetMapping("/show")
	public String viewDoctorAppointments(Model model, Principal principal) {
		User doctor = userService.findByEmail(principal.getName());
		List<Appointment> doctorAppointments = appointmentService.getAppointmentsByDoctor(doctor);
		model.addAttribute("appointments", doctorAppointments);
		return "viewAppointmentList";
	}

	@GetMapping("/add")
	public String showAddAppointmentForm(Model model) {
		model.addAttribute("appointment", new Appointment());
		LocalDate currentDate = LocalDate.now();

		// Replace 1L with the actual ID of the selected doctor
		Long selectedDoctorId = 1L; // You should retrieve this from your session or model

		List<String> availableTimeSlots = appointmentService.findAvailableTimeSlots(currentDate, selectedDoctorId);
		model.addAttribute("availableTimeSlots", availableTimeSlots);

		return "addAppointmentForm";
	}

	@PostMapping("/add")
	public String addAppointment(@ModelAttribute("appointment") Appointment appointment) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String userEmail = authentication.getName();
		appointment.setPatientEmail(userEmail);
		appointment.setStatus(AppointmentStatus.PENDING);
		System.out.println(appointment);
		appointmentService.saveAppointment(appointment);
		return "redirect:/appointments";
	}

	@GetMapping("/edit/{id}")
	public String showEditForm(@PathVariable("id") Long id, Model model) {
		System.out.println("inside doctor ");
		Appointment appointment = appointmentService.getAppointmentById(id);
		model.addAttribute("appointment", appointment);
		return "editAppointmentForm";
	}

	@PostMapping("/edit/{id}")
	public String updateAppointment(@PathVariable("id") Long id,
			@ModelAttribute("appointment") Appointment updatedAppointment) {
		appointmentService.updateAppointment(id, updatedAppointment);
		return "redirect:/appointments/show";
	}

	
	@GetMapping("/view/{id}")
	public String showViewForm(@PathVariable("id") Long id, Model model) {
		Appointment appointment = appointmentService.getAppointmentById(id);
		model.addAttribute("appointment", appointment);
		return "viewAppointmentDetails";
	}

	@GetMapping("show/view/{id}")
	public String ViewForm(@PathVariable("id") Long id, Model model) {
		Appointment appointment = appointmentService.getAppointmentById(id);
		model.addAttribute("appointment", appointment);
		return "viewAppointmentInfo";
	}

	@GetMapping("/delete/{id}")
	public String deleteAppointment(@PathVariable("id") Long id) {
		System.out.println("inside doctors delete");
		appointmentService.deleteAppointment(id);
		return "redirect:/appointments/show";
	}

	@ModelAttribute("isDoctor")
	public boolean isDoctor(HttpServletRequest request) {
		String requestURI = request.getRequestURI();
		boolean isEditOperation = requestURI.contains("/edit/");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return authentication.getAuthorities().stream().anyMatch(role -> role.getAuthority().equals("ROLE_DOCTOR"))
				&& isEditOperation;
	}


	@GetMapping("/download/csv")
	public ResponseEntity<byte[]> downloadCsv() {
		List<Appointment> appointments = appointmentService.getAllAppointments();
		byte[] csvData = CsvUtils.generateCsvData(appointments);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType("text/csv"));
		headers.setContentDispositionFormData("attachment", "appointments.csv");

		return new ResponseEntity<>(csvData, headers, HttpStatus.OK);
	}

	@PostMapping("/updateStatus/{id}")
	public String updateStatus(@PathVariable("id") Long id, @RequestParam("status") AppointmentStatus status) {
		Appointment appointment = appointmentService.getAppointmentById(id);
		appointment.setStatus(status);
		appointmentService.updateAppointment(id, appointment);

		return "redirect:/appointments/show";
	}

	@GetMapping("/getAvailableTimeSlots")
	@ResponseBody
	public List<String> getAvailableTimeSlots(@RequestParam("selectedDate") String selectedDate,
			@RequestParam("selectedDoctorId") Long selectedDoctorId) {
		LocalDate date = LocalDate.parse(selectedDate);
		return appointmentService.findAvailableTimeSlots(date, selectedDoctorId);
	}

	@ModelAttribute("doctors")
	public List<User> getDoctors() {
		return userService.getDoctors(); // Implement this method in your UserService
	}

}
