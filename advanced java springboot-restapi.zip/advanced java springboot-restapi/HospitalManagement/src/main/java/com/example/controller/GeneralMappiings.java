package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GeneralMappiings {

	@RequestMapping("/user/aboutus")
	public String about() {
		return "aboutus";
	}
	
	@RequestMapping("/user/services")
	public String services() {
		return "services";
	}
	
	@RequestMapping("/doctor/services")
	public String Services() {
		return "services";
	}
}
