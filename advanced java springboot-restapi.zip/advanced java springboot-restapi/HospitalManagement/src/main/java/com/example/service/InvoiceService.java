package com.example.service;

import com.example.entity.Appointment;
import com.example.entity.User;
import com.example.repository.AppointmentRepository;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
//InvoiceService.java
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

/*
 * @Service public class InvoiceService {
 * 
 * @Autowired private AppointmentRepository appointmentRepository; // Assuming
 * you have an AppointmentRepository for database // interactions
 * 
 * public byte[] generateInvoiceByAppointment(Long appointmentId) throws
 * DocumentException { // Fetch appointment details from the database
 * Appointment appointment = appointmentRepository.findById(appointmentId)
 * .orElseThrow(() -> new RuntimeException("Appointment not found"));
 * 
 * // You can access patient details from the appointment, adjust this part
 * based // on your entity relationships
 * 
 * 
 * Document document = new Document(); ByteArrayOutputStream
 * byteArrayOutputStream = new ByteArrayOutputStream();
 * PdfWriter.getInstance(document, byteArrayOutputStream);
 * 
 * document.open(); document.add(new Paragraph("Invoice for Appointment: " +
 * appointment.getId())); document.add(new Paragraph("Patient Name: " +
 * appointment.getPatientName())); document.add(new
 * Paragraph("Appointment Date: " + appointment.getAppointmentDate()));
 * document.add(new Paragraph("Appointment Time: " +
 * appointment.getAppointmentTime())); document.add(new
 * Paragraph("Appointment Fee: " + appointment.getAppointmentFee()));
 * 
 * // Add more details as needed
 * 
 * document.close(); return byteArrayOutputStream.toByteArray(); } }
 */

//InvoiceService.java
@Service
public class InvoiceService {

//	@Autowired
//	private AppointmentRepository appointmentRepository;
//
//	public byte[] generateInvoiceByAppointment(Long appointmentId) throws DocumentException {
//		// Fetch appointment details from the database
//		Appointment appointment = appointmentRepository.findById(appointmentId)
//				.orElseThrow(() -> new RuntimeException("Appointment not found"));
//
//		// Check if patient is null
//		if (appointment.getPatient() == null) {
//			throw new RuntimeException("Patient not found for the appointment");
//		}
//
//		// Fetch patient details from the appointment
//		
//
//		Document document = new Document();
//		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//		PdfWriter.getInstance(document, byteArrayOutputStream);
//
//		document.open();
//
//		// Add invoice header
//		addInvoiceHeader(document);
//
//		// Add patient and appointment details
//		
//		addAppointmentDetails(document, appointment);
//
//		document.close();
//		return byteArrayOutputStream.toByteArray();
//	}
//
//	private void addInvoiceHeader(Document document) throws DocumentException {
//		Font fontHeader = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK);
//
//		Paragraph invoiceHeader = new Paragraph();
//		invoiceHeader.setAlignment(Element.ALIGN_CENTER);
//		invoiceHeader.setFont(fontHeader);
//		invoiceHeader.add("Invoice");
//
//		document.add(invoiceHeader);
//		document.add(Chunk.NEWLINE); // Add a new line after the header
//	}
//
//	private void addPatientDetails(Document document) throws DocumentException {
//		Font fontPatientDetails = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);
//
//		Paragraph patientDetails = new Paragraph();
//		patientDetails.setAlignment(Element.ALIGN_LEFT);
//		patientDetails.setFont(fontPatientDetails);
//		
//		// Add more patient details as needed
//
//		document.add(patientDetails);
//		document.add(Chunk.NEWLINE); // Add a new line after patient details
//	}
//
//	private void addAppointmentDetails(Document document, Appointment appointment) throws DocumentException {
//		Font fontAppointmentDetails = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);
//
//		Paragraph appointmentDetails = new Paragraph();
//		appointmentDetails.setAlignment(Element.ALIGN_LEFT);
//		appointmentDetails.setFont(fontAppointmentDetails);
//		appointmentDetails.add("Appointment Date: " + appointment.getAppointmentDate());
//		appointmentDetails.add(Chunk.NEWLINE);
//		appointmentDetails.add("Appointment Time: " + appointment.getAppointmentTime());
//		appointmentDetails.add(Chunk.NEWLINE);
//		appointmentDetails.add("Appointment Fee: $" + appointment.getAppointmentFee());
//		// Add more appointment details as needed
//
//		document.add(appointmentDetails);
//	}
	 @Autowired
	    private AppointmentRepository appointmentRepository;

	    public byte[] generateInvoiceByAppointment(Long appointmentId) throws DocumentException {
	        // Fetch appointment details from the database
	        Appointment appointment = appointmentRepository.findById(appointmentId)
	                .orElseThrow(() -> new RuntimeException("Appointment not found"));

	       

	        // Fetch patient details from the appointment
	      

	        Document document = new Document();
	        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	        PdfWriter.getInstance(document, byteArrayOutputStream);

	        document.open();

	        // Add invoice header
	        addInvoiceHeader(document);

	        // Add patient and appointment details
	       
	        addAppointmentDetails(document, appointment);

	        document.close();
	        return byteArrayOutputStream.toByteArray();
	    }

	    private void addInvoiceHeader(Document document) throws DocumentException {
	        Font fontHeader = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK);

	        Paragraph invoiceHeader = new Paragraph();
	        invoiceHeader.setAlignment(Element.ALIGN_CENTER);
	        invoiceHeader.setFont(fontHeader);
	        invoiceHeader.add("Invoice");
	        document.add(invoiceHeader);
	        document.add(Chunk.NEWLINE); 
	    }

	    private void addPatientDetails(Document document) throws DocumentException {
	        Font fontPatientDetails = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);
	        Paragraph patientDetails = new Paragraph();
	        patientDetails.setAlignment(Element.ALIGN_LEFT);
	        patientDetails.setFont(fontPatientDetails);
	        patientDetails.add(Chunk.NEWLINE);
	        document.add(patientDetails);
	        document.add(Chunk.NEWLINE);
	    }

	    private void addAppointmentDetails(Document document, Appointment appointment) throws DocumentException {
	        Font fontAppointmentDetails = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);
	        Paragraph appointmentDetails = new Paragraph();
	        appointmentDetails.setAlignment(Element.ALIGN_LEFT);
	        appointmentDetails.setFont(fontAppointmentDetails);
	        appointmentDetails.add("Patient Name: " + appointment.getPatientName());
	        appointmentDetails.add(Chunk.NEWLINE);
	        appointmentDetails.add("Appointment Date: " + appointment.getAppointmentDate());
	        appointmentDetails.add(Chunk.NEWLINE);
	        appointmentDetails.add("Appointment Time: " + appointment.getAppointmentTime());
	        appointmentDetails.add(Chunk.NEWLINE);
	        appointmentDetails.add("Medicle Prescription: " + appointment.getMedicalPrescription());
	        appointmentDetails.add(Chunk.NEWLINE);
	        appointmentDetails.add("Appointment Fee: $" + appointment.getAppointmentFee());
	        document.add(appointmentDetails);
	    }
}
