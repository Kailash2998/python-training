package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.entity.Appointment;
import com.example.entity.AppointmentStatus;
import com.example.entity.User;
import com.example.repository.AppointmentRepository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentRepository appointmentRepository;

	@Override
	public List<Appointment> getAllAppointments() {
		return appointmentRepository.findAll();
	}

	@Override
	public Appointment getAppointmentById(Long id) {
		return appointmentRepository.findById(id).orElse(null);
	}

	@Override
	public Appointment saveAppointment(Appointment appointment) {
		return appointmentRepository.save(appointment);
	}

	@Override
	public void deleteAppointment(Long id) {
		appointmentRepository.deleteById(id);
	}

	@Override
	public void updateAppointment(Long id, Appointment updatedAppointment) {
		Appointment existingAppointment = appointmentRepository.findById(id).orElse(null);
		if (existingAppointment != null) {
			existingAppointment.setMedicalPrescription(updatedAppointment.getMedicalPrescription());
			existingAppointment.setPatientName(updatedAppointment.getPatientName());
			existingAppointment.setGender(updatedAppointment.getGender());
			existingAppointment.setAddress(updatedAppointment.getAddress());
			existingAppointment.setAppointmentTime(updatedAppointment.getAppointmentTime());
			existingAppointment.setBloodGroup(updatedAppointment.getBloodGroup());
			existingAppointment.setAppointmentDate(updatedAppointment.getAppointmentDate());
			existingAppointment.setStatus(updatedAppointment.getStatus());
			existingAppointment.setAppointmentFee(updatedAppointment.getAppointmentFee());
			existingAppointment.setReason(updatedAppointment.getReason());
			appointmentRepository.save(existingAppointment);
		}
	}

	@Override
	public long getTotalAppointmentsCount() {
		return appointmentRepository.count();
	}

	@Override
	public long getApprovedAppointmentsCount() {
		return appointmentRepository.countByStatus(AppointmentStatus.APPROVED);
	}

	@Override
	public long getDeniedAppointmentsCount() {
		return appointmentRepository.countByStatus(AppointmentStatus.DENIED);
	}

	@Override
	public List<Appointment> getAppointmentsByPatientEmail(String patientEmail) {
		return appointmentRepository.findByPatientEmail(patientEmail);
	}

	@Autowired
    public AppointmentServiceImpl(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }
	
	@Override
	public List<String> findAvailableTimeSlots(LocalDate date, Long selectedDoctorId) {
		List<String> bookedTimeSlots = appointmentRepository.findBookedTimeSlotsByDateAndDoctor(date, selectedDoctorId);
		List<String> availableTimeSlots = new ArrayList<>();

		int startTime = 9;
		for (int i = 0; i < 7; i++) {
			int time = startTime + i;
			String period = (time <= 11) ? "AM" : "PM";
			int formattedTime = (time <= 12) ? time : time - 12;
			if (formattedTime == 0) {
				formattedTime = 12;
			}
			String formattedTimeString = (formattedTime < 10 ? "0" : "") + formattedTime + ":00 " + period;

			if (!bookedTimeSlots.contains(formattedTimeString)) {
				availableTimeSlots.add(formattedTimeString);
			}
		}
		return availableTimeSlots;
	}

	@Override
	public List<Appointment> getAppointmentsByDoctor(User doctor) {
		// TODO Auto-generated method stub
		return appointmentRepository.findByDoctor(doctor);
	}

	@Override
	public long getTotalAppointmentsCountForDoctor(User doctor) {
		return appointmentRepository.countByDoctor(doctor);
	}

	@Override
	public long getApprovedAppointmentsCountForDoctor(User doctor) {
		return appointmentRepository.countByDoctorAndStatus(doctor, AppointmentStatus.APPROVED);
	}

	@Override
	public long getDeniedAppointmentsCountForDoctor(User doctor) {
		return appointmentRepository.countByDoctorAndStatus(doctor, AppointmentStatus.DENIED);
	}

	@Override
	public long countMalePatients() {
		// TODO Auto-generated method stub
		return appointmentRepository.countByGender("Male");
		
	}

	@Override
	public long countFemalePatients() {
		// TODO Auto-generated method stub
		return appointmentRepository.countByGender("Female");
	}
	
	
	
}
