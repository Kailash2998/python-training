package com.example.entity;

import java.sql.Date;
import java.sql.Time;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String patientName;
	private String gender;
	private String bloodGroup;
	private Date appointmentDate;
	private String appointmentTime;
	private String reason;
	private String address;
	private String medicalPrescription;
	private Double appointmentFee;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private AppointmentStatus status;

	@ManyToOne
	@JoinColumn(name = "patient_id")
	private User patient;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "doctor_id")
	private User doctor;

	

	public Appointment(String patientName, String gender, String bloodGroup, Date appointmentDate,
			String appointmentTime, String reason, String address, String medicalPrescription, Double appointmentFee,
			AppointmentStatus status, User patient, User doctor, String patientEmail) {
		super();
		this.patientName = patientName;
		this.gender = gender;
		this.bloodGroup = bloodGroup;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.reason = reason;
		this.address = address;
		this.medicalPrescription = medicalPrescription;
		this.appointmentFee = appointmentFee;
		this.status = status;
		this.patient = patient;
		this.doctor = doctor;
		this.patientEmail = patientEmail;
	}

	public Double getAppointmentFee() {
		return appointmentFee;
	}

	public void setAppointmentFee(Double appointmentFee) {
		this.appointmentFee = appointmentFee;
	}

	public String getPatientEmail() {
		return patientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}

	@Column(name = "patient_email")
	private String patientEmail;

	public User getPatient() {
		return patient;
	}

	public void setPatient(User patient) {
		this.patient = patient;
	}

	public Appointment() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAppointmentTime() {
		return appointmentTime;
	}

	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	public String getMedicalPrescription() {
		return medicalPrescription;
	}

	public void setMedicalPrescription(String medicalPrescription) {
		this.medicalPrescription = medicalPrescription;
	}

	public AppointmentStatus getStatus() {
		return status;
	}

	public void setStatus(AppointmentStatus status) {
		this.status = status;
	}

	public User getDoctor() {
		return doctor;
	}

	public void setDoctor(User doctor) {
		this.doctor = doctor;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", patientName=" + patientName + ", gender=" + gender + ", bloodGroup="
				+ bloodGroup + ", appointmentDate=" + appointmentDate + ", appointmentTime=" + appointmentTime
				+ ", reason=" + reason + ", address=" + address + ", medicalPrescription=" + medicalPrescription
				+ ", appointmentFee=" + appointmentFee + ", status=" + status + ", patient=" + patient + ", doctor="
				+ doctor + ", patientEmail=" + patientEmail + "]";
	}

}