package com.example.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.entity.Appointment;
import com.example.entity.User;

public interface AppointmentService {
	List<Appointment> getAllAppointments();

	Appointment getAppointmentById(Long id);

	Appointment saveAppointment(Appointment appointment);

	void deleteAppointment(Long id);

	void updateAppointment(Long id, Appointment updatedAppointment);

	long getTotalAppointmentsCount(); // Add this method

	long getApprovedAppointmentsCount();

	long getDeniedAppointmentsCount();

	List<Appointment> getAppointmentsByPatientEmail(String patientEmail);

	/* List<String> findAvailableTimeSlots(LocalDate date); */
	 List<String> findAvailableTimeSlots(LocalDate date, Long selectedDoctorId);

	List<Appointment> getAppointmentsByDoctor(User doctor);

	long getTotalAppointmentsCountForDoctor(User doctor);

	long getApprovedAppointmentsCountForDoctor(User doctor);

	long getDeniedAppointmentsCountForDoctor(User doctor);
	
	long countMalePatients();

	long countFemalePatients();
	
}
