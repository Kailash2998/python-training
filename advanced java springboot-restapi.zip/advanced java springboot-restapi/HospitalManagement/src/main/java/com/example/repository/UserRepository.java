package com.example.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.entity.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	public User findByEmail(String emaill);

	boolean existsByEmail(String email);

	List<User> findByRole(String role);

	User findById(Long id);

	User save(User user);

	long count();

	long countByRole(String role);

	long countByRoleNot(String role);

	

}
