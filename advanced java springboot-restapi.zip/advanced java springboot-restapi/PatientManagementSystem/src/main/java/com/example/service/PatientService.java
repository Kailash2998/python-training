package com.example.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.model.Patient;

public interface PatientService extends UserDetailsService {
    void savePatient(Patient patient);
}

