package com.example.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Doctor;
import com.example.repository.DoctorRepository;

//DoctorService.java
@Service
public class DoctorService {

 @Autowired
 private DoctorRepository doctorRepository;

 public Optional<Doctor> findDoctorByEmail(String email) {
     return doctorRepository.findByEmail(email);
 }
}
