package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Patient;
import com.example.repository.PatientRepository;

import java.util.Optional;

@Service
public class PatientService {

 @Autowired
 private PatientRepository patientRepository;

 public void registerPatient(Patient patient) {
     patientRepository.save(patient);
 }

 public Optional<Patient> findPatientByEmail(String email) {
     return patientRepository.findByEmail(email);
 }
}
