package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.model.Doctor;
import com.example.model.Patient;
import com.example.service.DoctorService;
import com.example.service.PatientService;

import jakarta.servlet.http.HttpSession;

import java.util.Optional;

@Controller
public class PatientController {

	@Autowired
	private PatientService patientService;

	@Autowired
    private DoctorService doctorService;

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("patient", new Patient());
		return "registration";
	}

	@PostMapping("/register")
	public String registerPatient(@ModelAttribute("patient") Patient patient) {
		patientService.registerPatient(patient);
		return "redirect:/login";
	}

	 @GetMapping("/login")
	    public String showLoginForm(Model model) {
	        model.addAttribute("user", new Patient()); // Default to Patient, as it's the common case
	        return "login";
	    }

	 @PostMapping("/login")
	    public String loginUser(@ModelAttribute("user") Patient patient, HttpSession session) {
	        Optional<Patient> optionalPatient = patientService.findPatientByEmail(patient.getEmail());

	        if (optionalPatient.isPresent() && optionalPatient.get().getPassword().equals(patient.getPassword())) {
	            session.setAttribute("loggedInUser", optionalPatient.get());
	            return "patientDashboard";
	        } else {
	            // Check for Doctor login
	            Optional<Doctor> optionalDoctor = doctorService.findDoctorByEmail(patient.getEmail());

	            if (optionalDoctor.isPresent() && optionalDoctor.get().getPassword().equals(patient.getPassword())) {
	                session.setAttribute("loggedInUser", optionalDoctor.get());
	                return "doctorDashboard";
	            } else {
	                // Handle other cases or show an error
	                return "redirect:/login";
	            }
	        }
	    }

	@GetMapping("/logout")
    public String logout(HttpSession session) {
        // Invalidate the session
        session.invalidate();
        return "redirect:/login";
    }
	

}
