package com.example.model;

import java.util.List;

public class PostListResponse {

    private List<Post> data;

    public List<Post> getData() {
        return data;
    }

    public void setData(List<Post> data) {
        this.data = data;
    }
}
