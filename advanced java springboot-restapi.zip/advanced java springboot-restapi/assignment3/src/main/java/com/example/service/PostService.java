package com.example.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.model.Post;
import com.example.model.PostListResponse;

import java.util.Arrays;
import java.util.List;

@Service
public class PostService {

    @Value("${api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate;

    public PostService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Post> getAllPosts() {
        PostListResponse response = restTemplate.getForObject(apiUrl + "/posts", PostListResponse.class);
        return response.getData();
    }


    public Post getPostById(Long id) {
        String getUrl = apiUrl + "/posts/" + id;
        return restTemplate.getForObject(getUrl, Post.class);
    }

    public Post createPost(Post post) {
        String createUrl = apiUrl + "/posts";
        return restTemplate.postForObject(createUrl, post, Post.class);
    }

    public void updatePost(Long id, Post post) {
        String updateUrl = apiUrl + "/posts/" + id;
        restTemplate.put(updateUrl, post);
    }

    public void deletePost(Long id) {
        String deleteUrl = apiUrl + "/posts/" + id;
        restTemplate.delete(deleteUrl);
    }
}
