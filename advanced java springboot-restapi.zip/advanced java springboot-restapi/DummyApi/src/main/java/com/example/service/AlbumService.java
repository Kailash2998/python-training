
package com.example.service;

import com.example.model.Album;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class AlbumService {

    private final String apiUrl = "https://jsonplaceholder.typicode.com/albums";

    @Autowired
    private final RestTemplate restTemplate;

    public AlbumService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Album> getAllAlbums(Long id) {
        if (id != null) {
            // Search by ID
            String url = apiUrl + "/" + id;
            try {
                Album album = restTemplate.getForObject(url, Album.class);
                return Collections.singletonList(album);
            } catch (HttpClientErrorException.NotFound ex) {
                // Handle 404 (Not Found) exception when the record with the given ID is not found
                return Collections.emptyList();
            }
        } else {
            // Get all albums
            Album[] albums = restTemplate.getForObject(apiUrl, Album[].class);
            return Arrays.asList(albums);
        }
    }

    public Album getAlbumById(Long id) {
        String url = apiUrl + "/" + id;
        return restTemplate.getForObject(url, Album.class);
    }

    public void addAlbum(Album album) {
        restTemplate.postForObject(apiUrl, album, Album.class);
    }

    public void updateAlbum(Long id, Album album) {
        String url = apiUrl + "/" + id;
        restTemplate.put(url, album);
    }

    public void deleteAlbum(Long id) {
        String url = apiUrl + "/" + id;
        restTemplate.delete(url);
    }
}
