package com.example.model;

import java.util.List;

public class AlbumListResponse {
    private List<Album> albums;

    // Constructors
    public AlbumListResponse() {
    }

    public AlbumListResponse(List<Album> albums) {
        this.albums = albums;
    }

    // Getters and Setters
    public List<Album> getAlbums() {
        return albums;
    }

    public void setAlbums(List<Album> albums) {
        this.albums = albums;
    }

    // toString method for debugging or logging
    @Override
    public String toString() {
        return "AlbumListResponse{" +
                "albums=" + albums +
                '}';
    }
}
