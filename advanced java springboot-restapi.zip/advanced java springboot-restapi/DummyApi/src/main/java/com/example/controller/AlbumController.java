
package com.example.controller;

import com.example.model.Album;
import com.example.service.AlbumService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;

@Controller
@RequestMapping("/albums")
public class AlbumController {

	private static final Logger logger = LoggerFactory.getLogger(AlbumController.class);

	@Autowired
	private final AlbumService albumService;

	public AlbumController(AlbumService albumService) {
		this.albumService = albumService;
	}

	@GetMapping
	public String getAllAlbums(@RequestParam(required = false) Long id, Model model) {
		List<Album> albums = albumService.getAllAlbums(id);
		if (albums.isEmpty()) {
			// Redirect to the album list page if no records were found
			return "redirect:/albums";
		}
		model.addAttribute("albums", albums);
		logApiResponse("GET /albums", ResponseEntity.ok(albums));
		return "albumList";
	}
	
	@GetMapping("/new")
	public String showNewAlbumForm(Model model) {
		model.addAttribute("newAlbum", new Album());
		logApiResponse("GET /albums/new", ResponseEntity.ok("New Album form requested"));
		return "newAlbum";
	}

	@GetMapping("/view/{id}")
	public String viewAlbum(@PathVariable Long id, Model model) {
		Album album = albumService.getAlbumById(id);
		model.addAttribute("album", album);
		logApiResponse("GET /albums/view/" + id, ResponseEntity.ok(album));
		return "albumDetails"; // Thymeleaf template name for viewing a single album
	}

	@PostMapping("/new")
	public String addNewAlbum(@ModelAttribute("newAlbum") Album newAlbum, Model model) {
		newAlbum.setId(generateUniqueAlbumId());
		albumService.addAlbum(newAlbum);
		logApiResponse("POST /albums/new",
				ResponseEntity.status(HttpStatus.CREATED).body("New Album added: " + newAlbum));
		return "redirect:/albums";
	}

	private static AtomicLong idCounter = new AtomicLong(100);

	private Long generateUniqueAlbumId() {
		return idCounter.incrementAndGet();
	}

	@GetMapping("/edit/{id}")
	public String showEditAlbumForm(@PathVariable Long id, Model model) {
		Album album = albumService.getAlbumById(id);
		model.addAttribute("album", album);
		logApiResponse("GET /albums/edit/" + id, ResponseEntity.ok(album));
		return "editAlbum";
	}

	@PostMapping("/edit/{id}")
	public String updateAlbum(@PathVariable Long id, @ModelAttribute Album album) {
		albumService.updateAlbum(id, album);
		logApiResponse("POST /albums/edit/" + id, ResponseEntity.ok("Album updated: " + album));
		return "redirect:/albums";
	}

	@GetMapping("/delete/{id}")
	public String deleteAlbum(@PathVariable Long id) {
		albumService.deleteAlbum(id);
		logApiResponse("GET /albums/delete/" + id, ResponseEntity.ok("Album deleted: " + id));
		return "redirect:/albums";
	}

	private void logApiResponse(String endpoint, ResponseEntity<?> responseEntity) {
		logger.info("API Response for {}: {}", endpoint, responseEntity);
	}

}
