package com.example.model;

import java.util.UUID;

public class Album {
	
	
	private Long id;
    private Long userId;
    
    private String title;

    // Constructors
    public Album() {
    }

    public Album(Long userId, Long id, String title) {
        this.userId = userId;
        this.id = id;
        this.title = title;
    }

    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    public Album(Long userId, String title) {
        this.id = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE; // Generating a unique Long id
        this.userId = userId;
        this.title = title;
    }

    // toString method for debugging or logging
    @Override
    public String toString() {
        return "Album{" +
                "userId=" + userId +
                ", id=" + id +
                ", title='" + title + '\'' +
                '}';
    }
}
