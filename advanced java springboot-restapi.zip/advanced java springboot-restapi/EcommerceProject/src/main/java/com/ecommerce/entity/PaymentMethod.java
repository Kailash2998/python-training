package com.ecommerce.entity;

public enum PaymentMethod {
    CASH_ON_DELIVERY, ONLINE_PAYMENT
}