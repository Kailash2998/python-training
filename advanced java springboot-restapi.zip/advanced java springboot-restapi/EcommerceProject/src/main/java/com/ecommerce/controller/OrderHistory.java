package com.ecommerce.controller;

import java.io.IOException;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ecommerce.CsvUtils;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.User;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.UserService;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class OrderHistory {

	@Autowired
	private  UserRepository userRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private UserService userService;
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping("/order-history")
	public String viewOrderHistory(Model model, Principal principal) {
	    User user = userService.findByEmail(principal.getName());
	    List<Orderr> orderHistory = orderRepository.findByUserOrderByIdDesc(user);
	    model.addAttribute("orderHistory", orderHistory);
	    System.out.println(orderHistory);
	    
	    return "orderHistory";
	}

	@PostMapping("/cancel/{orderId}")
    public String cancelOrder(@PathVariable Long orderId) {
        orderService.cancelOrder(orderId);
        return "redirect:/order-history";
    }
	
	 @GetMapping("/downloadInvoice/order/{orderId}")
	    public ResponseEntity<byte[]> downloadInvoice(@PathVariable Long orderId) {
	        try {
	            byte[] pdfBytes = orderService.generateInvoiceByOrder(orderId);

	            HttpHeaders headers = new HttpHeaders();
	            headers.setContentType(MediaType.APPLICATION_PDF);
	            headers.setContentDispositionFormData("attachment", "invoice_order_" + orderId + ".pdf");

	            return new ResponseEntity<>(pdfBytes, headers, 200);
	        } catch (DocumentException e) {
	            e.printStackTrace();
	            return ResponseEntity.status(500).body(null);
	        }
	    }
	    
	    @GetMapping("/downloadOrders/csv")
	    public ResponseEntity<byte[]> downloadOrdersCsv() {
	        List<Orderr> orders = orderService.getAllOrders();
	        byte[] csvData = CsvUtils.generateOrdersCsvData(orders);

	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.parseMediaType("text/csv"));
	        headers.setContentDispositionFormData("attachment", "orders.csv");

	        return new ResponseEntity<>(csvData, headers, HttpStatus.OK);
	    }
}
