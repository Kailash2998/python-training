package com.ecommerce.service;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.hibernate.query.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.OrderNotFoundException;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.User;
import com.ecommerce.repository.OrderRepository;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayOutputStream;
import jakarta.transaction.Transactional;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Override
	public Orderr saveOrder(Orderr order) {
		return orderRepository.save(order);
	}

	@Override
	public List<Orderr> getAllOrders() {
		// Implement the logic to fetch all orders from the repository
		return orderRepository.findAll(); // Assuming findAll() exists in your repository
	}

	@Override
	public void cancelOrder(Long orderId) {
		Orderr order = orderRepository.findById(orderId)
				.orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

		// Check if the order is cancellable (e.g., not already cancelled)
		if (!order.isCancelled()) {
			order.setCancelled(true);
			orderRepository.save(order);
		}
	}

	@Override
	public Orderr getOrderById(Long orderId) {
		// Implement this method to fetch the order by ID from the repository
		return orderRepository.findById(orderId).orElse(null);
	}

	public byte[] generateInvoiceByOrder(Long orderId) throws DocumentException {
        // Fetch order details from the database
        Orderr order = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));

        Document document = new Document();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, byteArrayOutputStream);

        document.open();

        // Add invoice header with colorful background
        addInvoiceHeader(document);

        // Add order details
        addOrderDetails(document, order);

        document.close();
        return byteArrayOutputStream.toByteArray();
    }

    private void addInvoiceHeader(Document document) throws DocumentException {
        // Define fonts
        Font fontHeader = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, BaseColor.WHITE);
        
        // Define colors
        BaseColor headerColor = new BaseColor(209,156,151); // Brown color

        // Create header paragraph
        Paragraph header = new Paragraph("Order Invoice", fontHeader);
        header.setAlignment(Element.ALIGN_CENTER);
        
        // Create cell with background color
        PdfPCell cell = new PdfPCell(header);
        cell.setBackgroundColor(headerColor);
        cell.setBorder(Rectangle.NO_BORDER);
        
        // Add cell to the table
        PdfPTable table = new PdfPTable(1);
        table.setWidthPercentage(100);
        table.addCell(cell);
        
        // Add table to the document
        document.add(table);
        document.add(Chunk.NEWLINE); // Add some space
    }

    private void addOrderDetails(Document document, Orderr order) throws DocumentException {
        Font fontOrderDetails = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);

        // Create table for order details
        PdfPTable table = new PdfPTable(2); // 2 columns
        table.setWidthPercentage(100);
        table.getDefaultCell().setPaddingTop(10);
        // Add order details to the table
        addToTable(table, "Order ID:", order.getId().toString(), fontOrderDetails);
        addToTable(table, "Receiver Name:", order.getReceiverName(), fontOrderDetails);
        addToTable(table, "Product Name:", order.getCart().getProduct().getName(), fontOrderDetails);
        addToTable(table, "Product Quantity:", String.valueOf(order.getCart().getProduct().getQuanity()), fontOrderDetails);
        addToTable(table, "Order Status:", order.getOrderStatus().toString(), fontOrderDetails);
        addToTable(table, "Total Amount:", "$" + order.getTotalAmount(), fontOrderDetails);

        // Add table to the document
        document.add(table);
    }

    private void addToTable(PdfPTable table, String key, String value, Font font) {
        PdfPCell cellKey = new PdfPCell(new Phrase(key, font));
        cellKey.setPaddingTop(10); // Set padding top for this cell
        table.addCell(cellKey);
        
        PdfPCell cellValue = new PdfPCell(new Phrase(value, font));
        cellValue.setPaddingTop(10); // Set padding top for this cell
        table.addCell(cellValue);
    }
    
	@Override
	public List<Orderr> getOrdersBySeller(User seller) {
		return orderRepository.findOrdersBySeller(seller);
	}

	@Override
	public long getTotalOrderCount() {
		// TODO Auto-generated method stub
		return orderRepository.count();
	}

	@Override
	public long getPendingOrderCount() {
		// TODO Auto-generated method stub
		return orderRepository.countByOrderStatus(OrderStatus.PENDING);
	}

	@Override
	public long getConfirmedOrderCount() {
		// TODO Auto-generated method stub
		return orderRepository.countByOrderStatus(OrderStatus.CONFIRMED);
	}

	@Override
	public long getShippedOrderCount() {
		// TODO Auto-generated method stub
		return orderRepository.countByOrderStatus(OrderStatus.SHIPPED);
	}

	@Override
	public long getDeliveredOrderCount() {
		// TODO Auto-generated method stub
		return orderRepository.countByOrderStatus(OrderStatus.DELIVERED);
	}

	@Override
	public long getCancelledOrderCount() {
		// TODO Auto-generated method stub
		return orderRepository.countByOrderStatus(OrderStatus.CANCELLED);
	}
	
	@Override
    public List<Orderr> getOrdersByStatus(OrderStatus status) {
        return orderRepository.findByOrderStatus(status);
    }
	
	@Override
    public Page<Orderr> getOrdersBySeller(String email, Pageable pageable) {
        return orderRepository.findByUser(email, pageable);
    }
}