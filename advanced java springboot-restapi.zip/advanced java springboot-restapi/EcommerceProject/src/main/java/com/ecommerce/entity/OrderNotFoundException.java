package com.ecommerce.entity;

public class OrderNotFoundException extends RuntimeException {
	// Default constructor
	public OrderNotFoundException() {
		super();
	}

	// Constructor with a message parameter
	public OrderNotFoundException(String message) {
		super(message);
	}
}
