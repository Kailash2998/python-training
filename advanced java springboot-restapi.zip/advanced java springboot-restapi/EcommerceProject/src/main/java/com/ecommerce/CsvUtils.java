package com.ecommerce;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

import com.ecommerce.entity.Orderr;
import com.opencsv.CSVWriter;

public class CsvUtils {
    // ... existing code

    public static byte[] generateOrdersCsvData(List<Orderr> orders) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             CSVWriter csvWriter = new CSVWriter(new OutputStreamWriter(baos))) {
            String[] header = { "Order ID", "Receiver Name", "Phone Number", "Shipping Address", "Pin Code",  "Order Status" ,"Total Amount"};
            csvWriter.writeNext(header);
            for (Orderr order : orders) {
                String[] rowData = { String.valueOf(order.getId()), order.getReceiverName(),
                        order.getPhoneNumber(), order.getShippingAddress(), order.getPinCode(),String.valueOf(order.getOrderStatus()),
                        String.valueOf(order.getTotalAmount()) };
                csvWriter.writeNext(rowData);
            }
            csvWriter.flush();
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }
}
