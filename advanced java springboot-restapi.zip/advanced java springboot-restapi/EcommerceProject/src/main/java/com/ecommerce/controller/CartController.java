//package com.ecommerce.controller;
//
//import java.math.BigDecimal;
//import java.security.Principal;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import com.ecommerce.entity.Cart;
//import com.ecommerce.entity.Product;
//import com.ecommerce.entity.User;
//import com.ecommerce.repository.CartRepository;
//import com.ecommerce.service.CartService;
//import com.ecommerce.service.ProductService;
//import com.ecommerce.service.UserService;
//
//@Controller
//public class CartController {
//
//	@Autowired
//	private CartService cartService;
//
//	@Autowired
//	private ProductService productService;
//
//	@Autowired
//	private UserService userService;
//
//	@Autowired
//	private CartRepository cartRepository;
//
//	@PostMapping("/add-to-cart")
//	public String addToCart(@RequestParam Long productId, @RequestParam(defaultValue = "1") int quantity,
//			Principal principal) {
//		Optional<Product> optionalProduct = productService.findById(productId);
//		optionalProduct.ifPresent(product -> {
//			User user = userService.findByEmail(principal.getName());
//			System.out.println("Product added to cart: " + product.getName());
//			cartService.addToCart(product.getId(), quantity, user);
//		});
//		return "redirect:/customer/profile";
//	}
//
//	@GetMapping("/cart")
//	public String viewCart(Model model, Principal principal, Long ID) {
//		User user = userService.findByEmail(principal.getName());
//		Map<Long, Integer> cartItems = cartService.getCartItemsByUser(user);
//		Map<Product, Integer> cartWithNames = new HashMap<>();
//		cartItems.forEach((productId, quantity) -> {
//			Optional<Product> optionalProduct = productService.findById(productId);
//			optionalProduct.ifPresent(product -> cartWithNames.put(product, quantity));
//		});
//		model.addAttribute("cartItems", cartWithNames);
//		BigDecimal totalAmount = cartService.calculateTotalAmount(cartItems);
//		model.addAttribute("totalAmount", totalAmount);
//		return "cart";
//	}
//
//	@GetMapping("/remove")
//	public String removeCartItem(@RequestParam Long cartItemId) {
//		cartService.removeCartItem(cartItemId);
//		return "redirect:/cart";
//	}
//
//}
package com.ecommerce.controller;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Category;
import com.ecommerce.entity.InsufficientStockException;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartRepository;
import com.ecommerce.service.CartService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserService;

@Controller
public class CartController {

	@Autowired
	private CartService cartService;

	@Autowired
	private ProductService productService;

	@Autowired
	private UserService userService;

	@Autowired
	private CartRepository cartRepository;

	@PostMapping("/add-to-cart")
	public String addToCart(@RequestParam Long productId, @RequestParam(defaultValue = "1") int quantity,
			Principal principal) {
		Optional<Product> optionalProduct = productService.findById(productId);
		optionalProduct.ifPresent(product -> {
			User user = userService.findByEmail(principal.getName());
			System.out.println("Product added to cart: " + product.getName());
			cartService.addToCart(product.getId(), quantity, user);
		});
		return "redirect:/customer/profile";
	}

	@GetMapping("/cart")
	public String viewCart(Model model, Principal principal) {
		User user = userService.findByEmail(principal.getName());
		Map<Long, Integer> cartItems = cartService.getCartItemsByUser(user);
		Map<Product, Integer> cartWithNames = new HashMap<>();
		cartItems.forEach((productId, quantity) -> {
			Optional<Product> optionalProduct = productService.findById(productId);
			optionalProduct.ifPresent(product -> cartWithNames.put(product, quantity));
		});
		model.addAttribute("cartItems", cartWithNames);
		Long stockQuantity = productService.getProductStockQuantity(1L);
		model.addAttribute("stockQuantity", stockQuantity);

		List<Long> productIds = cartService.getDistinctProductIds();

		// Iterate over each product ID to calculate the complete quantity
		for (Long productId : productIds) {
			int completeQuantity = cartService.countCompleteProductQuantity(productId);
			System.out.println("Complete quantity for product with ID " + productId + ": " + completeQuantity);
		}
		List<Cart> pendingCartItems = cartService.getPendingCartItemsByUser(user);
		BigDecimal totalAmount = cartService.calculateTotalAmount(pendingCartItems);
		model.addAttribute("totalAmount", totalAmount);
		List<Cart> pendingCarts = cartRepository.findByUserAndStatus(user, "pending");
		model.addAttribute("pendingCarts", pendingCarts);
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("categories", categories);
		return "cart";
	}

	
	@GetMapping("/remove")
	public String removeCartItem(@RequestParam Long cartItemId) {
		cartService.removeCartItem(cartItemId);
		return "redirect:/cart";
	}

	@PostMapping("/edit-cart")
	public String editCartItem(@RequestParam Long cartItemId, @RequestParam int quanity, Model model) {
		try {
			cartService.updateQuantity(cartItemId, quanity);
		} catch (InsufficientStockException e) {
			model.addAttribute("error", e.getMessage());
			return "redirect:/cart";
		}
		return "redirect:/cart";
	}
}
