package com.ecommerce.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Category;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.CartService;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;

	@Autowired
	private OrderService orderService;

	@ModelAttribute
	public void commonUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			User user = userRepository.findByEmail(email);
			m.addAttribute("user", user);
		}
	}

	@GetMapping("/profile")
	public String customer(Model model, Principal principal, @RequestParam(defaultValue = "0") int page) {
	    int pageSize = 3; // Or any other desired page size
	    User customer = userService.findByEmail(principal.getName());
	    model.addAttribute("customer", customer);
	    Page<Product> productsPage = productService.findAll(PageRequest.of(page, pageSize));
	    List<Product> products = productsPage.getContent();
	    model.addAttribute("products", products);
	    model.addAttribute("currentPage", page);
	    model.addAttribute("totalPages", productsPage.getTotalPages());
	    List<Cart> pendingCartItems = cartService.getPendingCartItemsByUser(customer);
		model.addAttribute("cartSize", pendingCartItems.size());
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("categories", categories);
		model.addAttribute("products", products);
	    return "customerPage";
	}
	
	@PostMapping("/profile/search")
	public String searchProducts(@RequestParam("query") String query, Model model, Principal principal) {
	    User customer = userService.findByEmail(principal.getName());
	    model.addAttribute("customer", customer);
	    List<Cart> pendingCartItems = cartService.getPendingCartItemsByUser(customer);
	    model.addAttribute("cartSize", pendingCartItems.size());
	    List<Category> categories = productService.getAllCategories();
	    model.addAttribute("categories", categories);
	    // Retrieve filtered products based on the search query
	    List<Product> filteredProducts = productService.searchProducts(query);
	    model.addAttribute("products", filteredProducts);
	    return "customerPage";
	}
	
	
	@PostMapping("/updateOrderStatus/{orderId}")
	public String updateOrderStatus(@PathVariable Long orderId, @RequestParam String status) {
		Orderr order = orderService.getOrderById(orderId);
		switch (status) {
		case "CONFIRMED":
			order.setOrderStatus(OrderStatus.CONFIRMED);
			break;
		case "SHIPPED":
			order.setOrderStatus(OrderStatus.SHIPPED);
			break;
		case "DELIVERED":
			order.setOrderStatus(OrderStatus.DELIVERED);
			break;
		case "CANCELLED":
			order.setOrderStatus(OrderStatus.CANCELLED);
			break;
		default:
			break;
		}

		orderService.saveOrder(order);
		if (status.equals("CANCELLED")) {
			Cart cart = order.getCart();
			Product product = cart.getProduct();
			long cancelledQuantity = cart.getQuanity();
			long currentQuantity = product.getQuanity();
			long newQuantity = currentQuantity + cancelledQuantity;
			product.setQuanity(newQuantity);
			productService.saveProduct(product);
		}
		return "redirect:/order-history";
	}

	@GetMapping("/customerProfile")
	public String customerProfile(Model model, Principal principal) {
		User customer = userService.findByEmail(principal.getName());
		model.addAttribute("customer", customer);
		System.out.println(customer);
		return "customerProfile";
	}

	@PostMapping("/saveProfile")
	public String saveProfile(@ModelAttribute User user, HttpSession session, Principal principal) {
		try {
			String userEmail = principal.getName();
			System.out.println(userEmail);
			User existingUser = userService.findByEmail(userEmail);
			if (existingUser != null) {
				existingUser.setFirstname(user.getFirstname());
				existingUser.setLastname(user.getLastname());
				existingUser.setMobileNo(user.getMobileNo());
				existingUser.setRegistrationDate(user.getRegistrationDate());
				existingUser.setCity(user.getCity());
				existingUser.setRole(user.getRole());
				existingUser.setPassword(existingUser.getPassword());
				userService.saveUser(existingUser);
				session.setAttribute("msg", "Profile updated successfully.");
			} else {
				session.setAttribute("msg", "User not found.");
			}
		} catch (Exception e) {
			session.setAttribute("msg", "Failed to update profile. Please try again.");
			e.printStackTrace();
		}
		return "redirect:/customer/customerProfile";
	}

}
