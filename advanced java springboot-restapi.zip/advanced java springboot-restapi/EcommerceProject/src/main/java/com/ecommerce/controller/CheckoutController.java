package com.ecommerce.controller;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Category;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartRepository;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.CartService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserService;

@Controller
public class CheckoutController {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CartService cartService;

	@Autowired
	private ProductService productService;

	@Autowired
	private UserService userService;

	@GetMapping("/checkout")
	public String showCheckoutForm(Model model, Principal principal) {
		model.addAttribute("order", new Orderr());
		User user = userService.findByEmail(principal.getName());
		List<Cart> pendingCartItems = cartService.getPendingCartItemsByUser(user);
		BigDecimal totalAmount = cartService.calculateTotalAmount(pendingCartItems);
		model.addAttribute("totalAmount", totalAmount);
		Map<Long, Integer> cartItems = cartService.getCartItemsByUser(user);
		Map<Product, Integer> cartWithNames = new HashMap<>();
		cartItems.forEach((productId, quantity) -> {
			Optional<Product> optionalProduct = productService.findById(productId);
			optionalProduct.ifPresent(product -> cartWithNames.put(product, quantity));
		});
		model.addAttribute("cartItems", cartWithNames);
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("categories", categories);
		return "checkoutForm"; 
	}

	@PostMapping("/checkout")
	public String processCheckoutForm(@ModelAttribute("order") Orderr order, @RequestParam BigDecimal totalAmount,
			Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String userEmail = authentication.getName();
		User user = userRepository.findByEmail(userEmail);
		List<Cart> pendingCarts = cartRepository.findByUserAndStatus(user, "pending");
		for (Cart cart : pendingCarts) {
			Orderr newOrder = new Orderr();
			newOrder.setShippingAddress(order.getShippingAddress());
			newOrder.setPhoneNumber(order.getPhoneNumber());
			newOrder.setReceiverName(order.getReceiverName());
			newOrder.setPinCode(order.getPinCode());
			newOrder.setPaymentMethod(order.getPaymentMethod());
			newOrder.setPaymentOption(order.getPaymentOption());
			newOrder.setTotalAmount(totalAmount);
			newOrder.setUser(user);
			newOrder.setOrderStatus(OrderStatus.PENDING);
			newOrder.setCart(cart);
			orderRepository.save(newOrder);
			Product product = cart.getProduct();
			int orderQuantity = cart.getQuanity();
	        productService.subtractQuantityFromProduct(cart.getProduct().getId(), orderQuantity);
			System.out.println("completeQuantity)"+orderQuantity);
			cart.setStatus("complete");
			cartRepository.save(cart);

		}
		return "redirect:/customer/profile";
	}

	private List<Cart> retrieveOrCreateCarts(User user) {
		List<Cart> pendingCarts = cartRepository.findByUserAndStatus(user, "pending");
		if (pendingCarts.isEmpty()) {
			Cart newCart = new Cart();
			newCart.setUser(user);
			cartRepository.save(newCart);
			pendingCarts.add(newCart);
		}
		return pendingCarts;
	}

}
