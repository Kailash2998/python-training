package com.ecommerce.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.Category;
import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private ProductService productService;

	@Autowired
	private OrderService orderService;
	private static final Logger logger = LoggerFactory.getLogger(OrderHistory.class);

	@ModelAttribute
	public void commonUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			User user = userRepository.findByEmail(email);
			m.addAttribute("user", user);
		}
	}

	@GetMapping("/profile")
	public String seller(Model model, Principal principal, @RequestParam(defaultValue = "0") int page) {
		String sellerEmail = principal.getName();
		int pageSize = 3; // Number of products per page
		Pageable pageable = PageRequest.of(page, pageSize);
		Page<Product> productPage = productService.getProductsBySellerEmail(sellerEmail, pageable);

		model.addAttribute("products", productPage.getContent());
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", productPage.getTotalPages());

		return "sellerPage";
	}

	@GetMapping("/products")
	public String showProductList(Model model, Principal principal , @RequestParam(defaultValue = "0") int page) {
		String sellerEmail = principal.getName(); // Get currently logged-in user's email
		int pageSize = 3; // Number of products per page
		Pageable pageable = PageRequest.of(page, pageSize);
		Page<Product> productPage = productService.getProductsBySellerEmail(sellerEmail, pageable);
		System.out.println();
		model.addAttribute("products", productPage.getContent());
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", productPage.getTotalPages());
		return "productList";
	}

	@GetMapping("/add")
	public String showAddProductForm(Model model) {
		model.addAttribute("product", new Product());
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("categories", categories);
		return "addProduct";
	}

	@PostMapping("/add")
	public String addProduct(@ModelAttribute("product") Product product, Model model,
			@RequestParam("resume") MultipartFile file, Principal principal) {
		try {
			String sellerEmail = principal.getName();
			User user = userService.getUserByEmail(sellerEmail);
			product.setUser(user);
			product.setFile(file.getOriginalFilename());
			File saveFile = new ClassPathResource("static/img").getFile();
			Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
			Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

		} catch (IOException e) {
			e.printStackTrace();
			model.addAttribute("error", "Error processing file");
		}
		productService.saveProduct(product);
		return "redirect:/seller/profile";
	}

	@GetMapping("/edit/{id}")
	public String showEditProductForm(@PathVariable Long id, Model model) {

		Product product = productService.getProductById(id);
		List<Category> categories = productService.getAllCategories();
		model.addAttribute("product", product);
		model.addAttribute("categories", categories);
		System.out.println(product);
		return "editProduct";
	}

	@PostMapping("/edit/{id}")
	public String editProduct(@PathVariable Long id, @ModelAttribute("product") Product editedProduct, Model model,
			@RequestParam("resume") MultipartFile file) {
		try {
			if (!file.isEmpty()) {
				editedProduct.setFile(file.getOriginalFilename());
				File saveFile = new ClassPathResource("static/img").getFile();
				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				System.out.println("File uploaded successfully!!!");
			}
			Product existingProduct = productService.getProductById(id);
			existingProduct.setName(editedProduct.getName());
			existingProduct.setDescription(editedProduct.getDescription());
			existingProduct.setPrice(editedProduct.getPrice());
			existingProduct.setCategory(editedProduct.getCategory());
			existingProduct.setSizes(editedProduct.getSizes());
			existingProduct.setColor(editedProduct.getColor());
			existingProduct.setBrand(editedProduct.getBrand());
			existingProduct.setQuanity(editedProduct.getQuanity());
			if (!file.isEmpty()) {
				existingProduct.setFile(editedProduct.getFile());
			}
			productService.saveProduct(existingProduct);
			return "redirect:/seller/products";
		} catch (IOException e) {
			e.printStackTrace();
			model.addAttribute("error", "Error processing file");
			return "errorPage";
		}
	}

	@GetMapping("/delete/{id}")
	public String deleteProduct(@PathVariable Long id) {
		productService.deleteProduct(id);
		return "redirect:/seller/products";
	}

	@GetMapping("/orders")
	public String showOrdersList(Model model, Principal principal) {
		String sellerEmail = principal.getName();
		User seller = userService.findByEmail(sellerEmail);
		List<Orderr> orders = orderService.getOrdersBySeller(seller);
		model.addAttribute("orders", orders);
		List<Orderr> cancelledOrders = orderService.getOrdersByStatus(OrderStatus.CANCELLED);
		for (Orderr order : cancelledOrders) {
			Cart cart = order.getCart();
			Product product = cart.getProduct();
		}
		return "sellerOrders";
	}
	
	@PostMapping("/updateOrderStatus/{orderId}")
	public String updateOrderStatus(@PathVariable Long orderId, @RequestParam String status) {
		Orderr order = orderService.getOrderById(orderId);
		switch (status) {
		case "CONFIRMED":
			order.setOrderStatus(OrderStatus.CONFIRMED);
			break;
		case "SHIPPED":
			order.setOrderStatus(OrderStatus.SHIPPED);
			break;
		case "DELIVERED":
			order.setOrderStatus(OrderStatus.DELIVERED);
			break;
		case "CANCELLED":
			order.setOrderStatus(OrderStatus.CANCELLED);
			break;
		default:
			break;
		}

		orderService.saveOrder(order);
		if (status.equals("CANCELLED")) {
			Cart cart = order.getCart();
			Product product = cart.getProduct();
			long cancelledQuantity = cart.getQuanity();
			long currentQuantity = product.getQuanity();
			long newQuantity = currentQuantity + cancelledQuantity;
			product.setQuanity(newQuantity);
			productService.saveProduct(product);
			System.out.println("Cancelled Order Details:");
			System.out.println("Product ID: " + product.getId());
			System.out.println("Cancelled Quantity: " + cancelledQuantity);
		}
		return "redirect:/seller/orders";
	}

	@GetMapping("/sellerProfile")
	public String customerProfile(Model model, Principal principal) {
		User customer = userService.findByEmail(principal.getName());
		model.addAttribute("customer", customer);
		System.out.println(customer);
		return "sellerProfile";
	}

	@PostMapping("/saveSellerProfile")
	public String saveProfile(@ModelAttribute User user, HttpSession session) {
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			String userEmail = authentication.getName();
			User existingUser = userService.findByEmail(userEmail);
			existingUser.setFirstname(user.getFirstname());
			existingUser.setLastname(user.getLastname());
			existingUser.setMobileNo(user.getMobileNo());
			existingUser.setRegistrationDate(user.getRegistrationDate());
			existingUser.setCity(user.getCity());
			existingUser.setRole(user.getRole());
			userService.saveUser(existingUser);
			session.setAttribute("msg", "Profile updated successfully.");
		} catch (Exception e) {
			session.setAttribute("msg", "Failed to update profile. Please try again.");
			e.printStackTrace();
		}
		return "redirect:/seller/sellerProfile"; 
	}

}
