package com.ecommerce.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ecommerce.entity.Product;

public interface AdminService {

	List<Product> getAllProducts();

    Product getProductById(Long productId);

    void addProduct(Product product);

    void editProduct(Long productId, Product updatedProduct);

    void deleteProduct(Long productId);
    
    Page<Product> getAllProductsPaginated(Pageable pageable);
}
