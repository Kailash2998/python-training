package com.ecommerce.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecommerce.entity.OrderStatus;
import com.ecommerce.entity.Orderr;
import com.ecommerce.entity.User;

@Repository
public interface OrderRepository extends JpaRepository<Orderr, Long> {
	 List<Orderr> findByUserOrderByIdDesc(User user);
	 @Query("SELECT o FROM Orderr o JOIN o.cart c JOIN c.product p WHERE p.user = :seller")
	 List<Orderr> findOrdersBySeller(User seller);
	 long countByOrderStatus(OrderStatus orderStatus);
	 List<Orderr> findByOrderStatus(OrderStatus status);
	 Page<Orderr> findByUser(String email, Pageable pageable);
}

