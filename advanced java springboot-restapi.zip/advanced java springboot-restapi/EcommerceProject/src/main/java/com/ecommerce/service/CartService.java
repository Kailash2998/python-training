//package com.ecommerce.service;
//
//import java.math.BigDecimal;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.ecommerce.entity.Cart;
//
//import com.ecommerce.entity.Product;
//import com.ecommerce.entity.User;
//import com.ecommerce.repository.CartRepository;
//
//import jakarta.persistence.EntityManager;
//import jakarta.persistence.EntityNotFoundException;
//import jakarta.persistence.PersistenceContext;
//
//@Service
//public class CartService {
//
//	@Autowired
//	private ProductService productService;
//
//	@Autowired
//	private CartRepository cartRepository;
//
//	private Map<Long, Integer> cartItems = new HashMap<>(); // Ensure the correct type parameters
//
//	public Map<Long, Integer> getCartItems() {
//		return Collections.unmodifiableMap(cartItems);
//	}
//	
//	@Transactional
//	public void addToCart(Long productId, int quantity, User user) {
//		Product product = productService.findById(productId).orElse(null);
//		if (product == null) {
//			return;
//		}
//		Optional<Cart> existingCartItem = cartRepository.findByUserAndProduct(user, product);
//
//		if (existingCartItem.isPresent()) {
//			Cart cartItem = existingCartItem.get();
//			cartItem.setQuanity(cartItem.getQuanity() + quantity);
//			cartRepository.save(cartItem);
//			System.out.println("Existing cart item updated. Product: " + product.getName() + ", Quantity: " + quantity);
//		} else {
//			Cart newCartItem = new Cart();
//			newCartItem.setUser(user);
//			newCartItem.setProduct(product);
//			newCartItem.setQuanity(quantity);
//			cartRepository.save(newCartItem);
//			System.out.println("New cart item added. Product: " + product.getName() + ", Quantity: " + quantity);
//		}
//	}
//
//	public void updateQuantity(Long cartItemId, Integer quantity) {
//		Optional<Cart> cartItem = cartRepository.findById(cartItemId);
//
//		if (cartItem.isPresent()) {
//			Cart existingCartItem = cartItem.get();
//			existingCartItem.setQuanity(quantity);
//			cartRepository.save(existingCartItem);
//		}
//	}
//
//	public BigDecimal calculateTotalAmount(Map<Long, Integer> cartItems) {
//		BigDecimal totalAmount = BigDecimal.ZERO;
//
//		for (Map.Entry<Long, Integer> entry : cartItems.entrySet()) {
//			Long productId = entry.getKey();
//			Integer quantity = entry.getValue();
//			BigDecimal productPrice = productService.getProductPriceById(productId);
//			BigDecimal subtotal = productPrice.multiply(BigDecimal.valueOf(quantity));
//			totalAmount = totalAmount.add(subtotal);
//		}
//
//		return totalAmount;
//	}
//
//	public Map<Long, Integer> getCartItemsByUser(User user) {
//		List<Cart> userCart = cartRepository.findByUser(user);
//		Map<Long, Integer> cartItems = new HashMap<>();
//
//		for (Cart cartItem : userCart) {
//			cartItems.put(cartItem.getProduct().getId(), cartItem.getQuanity());
//		}
//
//		return Collections.unmodifiableMap(cartItems);
//	}
//
//	@Transactional
//	public void removeCartItem(Long cartItemId) {
//		cartRepository.deleteById(cartItemId);
//		System.out.println("Cart item removed. CartItemId: " + cartItemId);
//	}
//
//}

package com.ecommerce.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.InsufficientStockException;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.UserRepository;

@Service
public class CartService {

	@Autowired
	private ProductService productService;

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private ProductServiceImpl productServiceImpl;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ProductRepository productRepository;

	private Map<Long, Integer> cartItems = new HashMap<>();

	public Map<Long, Integer> getCartItems() {
		return Collections.unmodifiableMap(cartItems);
	}

	@Transactional
	public void addToCart(Long productId, int quanity, User user) {
		Product product = productService.findById(productId).orElse(null);
		if (product == null) {
			return;
		}
		Optional<Cart> existingCartItem = cartRepository.findByUserAndProductAndStatus(user, product, "pending");

		if (existingCartItem.isPresent()) {
			Cart cartItem = existingCartItem.get();
			cartItem.setQuanity(cartItem.getQuanity() + quanity);
			cartItem.setStatus("pending");
			cartRepository.save(cartItem);
			System.out.println("Existing cart item updated. Product: " + product.getName() + ", Quanity: " + quanity);
		} else {
			Cart newCartItem = new Cart();
			newCartItem.setUser(user);
			newCartItem.setProduct(product);
			newCartItem.setQuanity(quanity);
			newCartItem.setStatus("pending");
			cartRepository.save(newCartItem);
			System.out.println("New cart item added. Product: " + product.getName() + ", Quanity: " + quanity);
		}
	}
	@Transactional
	public void updateQuantity(Long cartItemId, Integer newQuantity) throws InsufficientStockException {
		Optional<Cart> cartItemOptional = cartRepository.findById(cartItemId);

		if (cartItemOptional.isPresent()) {
			Cart cartItem = cartItemOptional.get();
			Product product = cartItem.getProduct();
			if (newQuantity <= product.getQuanity()) {
				cartItem.setQuanity(newQuantity);
				cartRepository.save(cartItem);
			} else {
				throw new InsufficientStockException("Not enough stock available for product: " + product.getName());
			}
		}
	}

	public BigDecimal calculateTotalAmount(Map<Long, Integer> cartItems) {
		BigDecimal totalAmount = BigDecimal.ZERO;

		for (Map.Entry<Long, Integer> entry : cartItems.entrySet()) {
			Long productId = entry.getKey();
			Integer quanity = entry.getValue();
			BigDecimal productPrice = productService.getProductPriceById(productId);
			BigDecimal subtotal = productPrice.multiply(BigDecimal.valueOf(quanity));
			totalAmount = totalAmount.add(subtotal);
		}

		return totalAmount;
	}

	public Map<Long, Integer> getCartItemsByUser(User user) {
		List<Cart> userCart = cartRepository.findByUser(user);
		Map<Long, Integer> cartItems = new HashMap<>();

		for (Cart cartItem : userCart) {
			cartItems.put(cartItem.getProduct().getId(), cartItem.getQuanity());
		}

		return Collections.unmodifiableMap(cartItems);
	}

	@Transactional
	public void removeCartItem(Long cartItemId) {
		cartRepository.deleteById(cartItemId);
		System.out.println("Cart item removed. CartItemId: " + cartItemId);
	}

	@Transactional
	public Cart getCartById(Long cartId) {
		return cartRepository.findByCartItemId(cartId);
	}

	@Transactional
	public boolean isQuantityValid(Long cartItemId, int newQuantity) {
		Cart cartItem = cartRepository.findById(cartItemId).orElse(null);

		if (cartItem == null) {
			// Handle the case where the cart item is not found
			return false;
		}

		Product product = cartItem.getProduct();
		Long stockQuantity = productServiceImpl.getStockQuantity(product.getId());

		return newQuantity <= stockQuantity;
	}

	@Transactional
	public User getCurrentUser() {
		String currentEmail = "currentEmail@example.com";
		return userRepository.findByEmail(currentEmail);
	}

	@Transactional
	public Product getProduct(Long productId) {
		return productRepository.findById(productId).orElse(null);
	}

	public void clearCart() {
		cartItems.clear();
	}

	@Transactional
	public List<Cart> getPendingCartItemsByUser(User user) {
		return cartRepository.findByUserAndStatus(user, "pending");
	}

	@Transactional
	public BigDecimal calculateTotalAmount(List<Cart> carts) {
		BigDecimal totalAmount = BigDecimal.ZERO;

		for (Cart cart : carts) {
			Product product = cart.getProduct();
			int quantity = cart.getQuanity();
			BigDecimal price = product.getPrice();
			BigDecimal subtotal = price.multiply(BigDecimal.valueOf(quantity));
			totalAmount = totalAmount.add(subtotal);
		}

		return totalAmount;
	}

	@Transactional(readOnly = true)
	public int countCompleteProductQuantity(Long productId) {
		return cartRepository.sumQuantityByProductIdAndStatus(productId, "complete");
	}
	
	@Transactional(readOnly = true)
    public List<Long> getDistinctProductIds() {
        return cartRepository.findDistinctProductIds();
    }
}
