package com.ecommerce.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.ecommerce.entity.Category;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;

public interface ProductService {

	List<Product> getAllProducts();

	Product getProductById(Long id);

	Product saveProduct(Product product);

	void deleteProduct(Long id);

	List<Category> getAllCategories();

	List<Product> getProductsBySellerEmail(String sellerEmail);

	List<Product> findAll();

	Optional<Product> findById(Long id);

	BigDecimal getProductPriceById(Long productId);

	void deleteProductById(Long id);

	Long getProductStockQuantity(Long productId);
	
	int countProductsBySeller(User seller);
	
	long getTotalProductCount();
	
	void subtractQuantityFromProduct(Long productId, int completeQuantity);
	
	List<Product> searchProducts(String query);
	
	List<Product> findPaginated(Pageable pageable);
    int getTotalPages(int pageSize);
    //List<Product> getProductsBySellerEmail(String email);
    Page<Product> getProductsBySellerEmail(String email, Pageable pageable);

	Page<Product> findAll(Pageable pageable);
}
