package com.thymleaf;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyController {

	@GetMapping("/about")
	public String about(Model model)
	{
		System.out.println("inside about handler");
		model.addAttribute("name","prathamesh");
		
		return "about";
	}
	
	@GetMapping("/iterate-example")
	public String iterate(Model model)
	{
		System.out.println("inside iterator handler");
		
		List<String> names = List.of("akshay","om","sai","raj");
		model.addAttribute("names",names);
		
		return "iterate-example";
	}
}
