package com.example.model;

//Employee.java
public class Employee {
 private Long id;
 private String employee_name;
 private double employee_salary;

 // Getters and setters

 public Long getId() {
     return id;
 }

 public void setId(Long id) {
     this.id = id;
 }

 public String getEmployee_name() {
     return employee_name;
 }

 public void setEmployee_name(String employee_name) {
     this.employee_name = employee_name;
 }

 public double getEmployee_salary() {
     return employee_salary;
 }

 public void setEmployee_salary(double employee_salary) {
     this.employee_salary = employee_salary;
 }
 

}

