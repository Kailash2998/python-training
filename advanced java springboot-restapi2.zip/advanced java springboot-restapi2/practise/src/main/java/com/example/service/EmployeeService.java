package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.model.Employee;
import com.example.model.EmployeeListResponse;

import java.util.List;

@Service
public class EmployeeService {

    private final String apiUrl = "http://dummy.restapiexample.com/api/v1/employees";
   

    @Autowired
    private RestTemplate restTemplate;

    public List<Employee> getAllEmployees() {
        EmployeeListResponse response = restTemplate.getForObject(apiUrl, EmployeeListResponse.class);
        return response.getData();
    }

    public Employee getEmployeeById(Long id) {        
        return restTemplate.getForObject("https://jsonplaceholder.typicode.com/posts/{id}", Employee.class,id);
    }

    public void addEmployee(Employee employee) {
        restTemplate.postForObject(apiUrl, employee, Employee.class);
        
    }

    public void updateEmployee(Long id, Employee employee) {
        String url = apiUrl + "/" + id;
        restTemplate.put(url, employee);
    }

    public void deleteEmployee(Long id) {
        String url = apiUrl + "/" + id;
        restTemplate.delete(url);
    }
}
