package com.example.controller;

//EmployeeController.java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.model.Employee;
import com.example.service.EmployeeService;

import java.util.List;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

 @Autowired
 private EmployeeService employeeService;

 @GetMapping
 public String getAllEmployees(Model model) {
     List<Employee> employees = employeeService.getAllEmployees();
     model.addAttribute("employees", employees);
     return "employeeList";
 }

 @GetMapping("/{id}")
 public String getEmployeeById(@PathVariable Long id, Model model) {
     Employee employee = employeeService.getEmployeeById(id);
     model.addAttribute("employee", employee);
     System.out.println(employee);
     return "employeeDetails";
 }

 @GetMapping("/new")
 public String showNewEmployeeForm(Model model) {
     model.addAttribute("employee", new Employee());
     return "newEmployee";
 }

 @PostMapping("/new")
 public String addEmployee(@ModelAttribute Employee employee) {
     employeeService.addEmployee(employee);
     return "redirect:/employees";
 }

 @GetMapping("/edit/{id}")
 public String showEditEmployeeForm(@PathVariable Long id, Model model) {
     Employee employee = employeeService.getEmployeeById(id);
     model.addAttribute("employee", employee);
     return "editEmployee";
 }

 @PostMapping("/edit/{id}")
 public String updateEmployee(@PathVariable Long id, @ModelAttribute Employee employee) {
     employeeService.updateEmployee(id, employee);
     return "redirect:/employees";
 }

 @GetMapping("/delete/{id}")
 public String deleteEmployee(@PathVariable Long id) {
     employeeService.deleteEmployee(id);
     return "redirect:/employees";
 }
}
