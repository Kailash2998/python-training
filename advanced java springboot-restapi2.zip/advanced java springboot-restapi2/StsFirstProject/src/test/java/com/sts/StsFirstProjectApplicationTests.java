package com.sts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StsFirstProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
