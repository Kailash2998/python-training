package com.sts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StsFirstProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StsFirstProjectApplication.class, args);
	}

}
