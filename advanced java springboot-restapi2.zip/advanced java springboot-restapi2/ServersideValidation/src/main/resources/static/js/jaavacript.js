/**
 * 
 */
alert("hello javascript !!!");