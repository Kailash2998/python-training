package com.validation.model;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class LoginData {

	@NotBlank(message="not blank")
	@Size(min=3,max=10,message="enter valid username")
	private String userName;
	
	@Pattern(regexp="^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",message="invalid email !!!")
	private String email;
	
	@AssertTrue(message="must valid terms and conditions !!!")
	private boolean aggreed;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "LoginData [userName=" + userName + ", email=" + email + "]";
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isAggreed() {
		return aggreed;
	}
	public void setAggreed(boolean aggreed) {
		this.aggreed = aggreed;
	}
}
