package com.jpa.test;

import java.util.List;
import java.util.Optional;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.jpa.test.dao.UserRepository;
import com.jpa.test.model.User;

@SpringBootApplication
public class SpringbootjpaApplication {

	public static void main(String[] args) {
		ApplicationContext context= SpringApplication.run(SpringbootjpaApplication.class, args);
		UserRepository userRepository = context.getBean(UserRepository.class);
		
//------------------------CRUD OPERTIONS----------------------------------------------------------	
//		1)create user
//		User user = new User();
//		user.setName("prathamesh shirsath");
//		user.setCity("dhule");
//		user.setStatus("I am java devloper");
//		User user1 = userRepository.save(user);
//		System.out.println(user1);
//		
		
		//2)update user
//		Optional <User> optional=userRepository.findById(52);
//		User user3 = optional.get();
//		user3.setName("sai");
//		User result = userRepository.save(user3);
//		
//		System.out.println(result);
		
		
		//3)get all the data from database
//		Iterable<User>Itr=userRepository.findAll();
//		Itr.forEach(user->{System.out.println(user);});
		
//		//4)delete user data
//		userRepository.deleteById(52);
//		System.out.println("deleted");
		
//		List<User>users = userRepository.findByName("prathamesh shirsath");
//		users.forEach(e->System.out.println(e));
		
		List<User> userByName = userRepository.getUserByName("prathamesh shirsath");
		userByName.forEach(e->{
			System.out.println(e);
		
		});
	}

}
