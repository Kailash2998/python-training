import React from "react";
import './Static.css';

function Static() {
  return (
    <div className="features-section">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 offset-lg-3">
            <div className="section-header wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="10ms">
              <h2>STATIC SECTION</h2>
              <p>Neque porro quisquam est,qui dolorem ipsum quia dolor sit amet consectetur, adipisci
                velit, sed quia
                non
                numquam</p>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 col-lg-4 features-col wow fadeInLeft" data-wow-duration="1000ms"
            data-wow-delay="100ms">
            <div className="feature-box clearfix">
              <figure className="image-outer">
                <i classclassName="fas fa-yin-yang"></i>
              </figure>
              <div className="text-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div className="col-md-6 col-lg-4 features-col  wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="200ms">
            <div className="feature-box clearfix">
              <figure className="image-outer">
                <i className="fas fa-warehouse"></i>
              </figure>
              <div className="text-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div className="col-md-6 col-lg-4 features-col wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
            <div className="feature-box clearfix">
              <figure className="image-outer">
                <i className="fas fa-space-shuttle"></i>
              </figure>
              <div className="text-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div className="col-md-6 col-lg-4 features-col wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">
            <div className="feature-box clearfix">
              <figure className="image-outer">
                <i className="fas fa-truck-moving"></i>
              </figure>
              <div className="text-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div 
          
          
      className="col-md-6 col-lg-4 features-col wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">
            <div className="feature-box clearfix">
              <figure className="image-outer">
                <i className="fas fa-trophy"></i>
              </figure>
              <div className="text-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div className="col-md-6 col-lg-4 features-col wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">
            <div className="feature-box clearfix">
              <figure className="image-outer">
                <i className="fas fa-tools"></i>
              </figure>
              <div className="text-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Static;