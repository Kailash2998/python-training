import React from "react";

function Props(Props) {
    const { name } = Props;

    return (
        <div className='row1'>
           <h4>Props Implementation using functional component</h4>
            Hello {Props.name}
        </div>
    )
}

export default Props;