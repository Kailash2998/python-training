
import React, { Component } from "react";
class Button extends Component {

  constructor ()
  {
    super()
    this.state = {
      message: "what is your name?"
    }
  }

  change(){
    this.setState({
      message: "PRATHAMESH MADHUKAR SHIRSATH"
    })
  }

  render() {
    return (
     
      <div class='row2'>
        <hr></hr><h2>{this.state.message}</h2>
        <button className="btn" onClick={() => this.change()}>Click me</button>
      </div>
    )
  }
}

export default Button;