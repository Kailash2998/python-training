import React from "react";
import './Footer.css';

function Footer() {
    return (
        <footer className="main-footer">
            <div className="container">
                <div className="copyright">
                    <p>&copy; Copyright &emsp;&emsp;&emsp; All rights reserved.</p>
                </div>
            </div>
        </footer>
    )
}

export default Footer;