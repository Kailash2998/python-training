import React from "react";
import './Header.css';

function Header() {

  return (
    <header className="main-header clearfix">
      <div className="container">
        <div className="logo">
          <figure><a href="index.html">ASSIGNMENT NO : 02</a></figure>
        </div>
        <nav className="navbar clearfix">
          <a href="javascript:void(0);" className="icon navbar-toggle" onclick="myFunction()">
            <i className="fa fa-bars" aria-hidden="true"></i>
          </a>
          <div className="topnav" id="myTopnav">
            <ul>
              <li><a href="index.html" className="active">HOME</a></li>
              <li><a href="#">SERVICES</a></li>
              <li><a href="#">PORTFOLIO</a></li>
              <li><a href="#">CONTACT</a></li>
            </ul>
          </div>
        </nav>
      </div>
    </header>
  )
}

export default Header;