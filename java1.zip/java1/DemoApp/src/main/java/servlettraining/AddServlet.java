package servlettraining;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/add")
public class AddServlet extends HttpServlet
{

	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		int i = Integer.parseInt(req.getParameter("num1"));
		int j = Integer.parseInt(req.getParameter("num2"));
		int k = i+j;
		
		PrintWriter out = res.getWriter();
		
//		out.println("<html><body bgcolor='cyan'>");
//		out.println("result is:"+k);
//		out.println("</body></html>");
//		req.setAttribute("k", k);
		
		//diffrent ways to call servlet from servlet
		//1)using ReuestDispatcher
		
//		RequestDispatcher rd = req.getRequestDispatcher("squrerroot");
//		rd.forward(req, res);
		
		//2)using SendRedirect
//		res.sendRedirect("squrerroot?k="+k);//using url rewriting
		
		//3)using seesion handling
		HttpSession session = req.getSession();
		session.setAttribute("k",k);
		res.sendRedirect("squrerroot");
	}
}
