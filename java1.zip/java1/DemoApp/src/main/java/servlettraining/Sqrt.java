
package servlettraining;

import java.io.IOException;

import java.io.PrintWriter;

import jakarta.servlet.ServletContext;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/squrerroot")
public class Sqrt extends HttpServlet
{
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException {
		
//		int k = (int)req.getAttribute("k");//using request dispatcher

//      int k = Integer.parseInt(req.getParameter("k"));//using send reuest redirect
		HttpSession session = req.getSession();
		int k = (int) session.getAttribute("k");
		
		k=k*k;
		
		PrintWriter out = res.getWriter();
		//write jsp code inside servlet using body & html tag
		out.println("<html><body bgcolor='cyan'>");
		out.println("Square is : "+k);
		out.println("</body></html>");
		
		
		System.out.println("squrerroot is called...!");
		
		
		
		//example of servlet config and servlet context
//		out.print("hello  ");
//		
//		ServletContext ctx = getServletContext();
//		String str = ctx.getInitParameter("name");
//		out.println(str);
//		out.print("contact:-  ");
//		String phone = ctx.getInitParameter("Phone");
//		out.println(phone);
		
	}
	
	
}
