package com.telusko;

import org.springframework.stereotype.Controller;

@Controller
public class AddControler {

	@RequestMapping ("/add");
	public void add() {
		System.out.println("hello everyone..!");
		
	}
}
