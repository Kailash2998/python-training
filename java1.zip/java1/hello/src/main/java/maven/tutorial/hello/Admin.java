package maven.tutorial.hello;

import org.springframework.stereotype.Component;

@Component
public class Admin implements Company
{

	public void register()
	{
		System.out.println("registration successfully approved");
	}
}
