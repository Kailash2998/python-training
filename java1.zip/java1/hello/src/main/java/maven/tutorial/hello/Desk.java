package maven.tutorial.hello;

import org.springframework.stereotype.Component;

@Component
public class Desk 
{
	/*
	 * public Desk(String type) { super(); this.type = type; }
	 */
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Its working...!";
	}
	
}
