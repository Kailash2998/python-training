package maven.tutorial.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee  implements Company
{
	@Autowired
	private Desk desk;
	
	public Desk getDesk() {
		return desk;
	}

	public void setDesk(Desk desk) {
		this.desk = desk;
	}

	public void register()
	{
		System.out.println("Employee ...!"+desk);
	}
}
