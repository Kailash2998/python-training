package maven.tutorial.hello;

public interface Company {

	void register();
}
