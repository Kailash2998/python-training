package maven.tutorial.hello;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
//    	Company a1 = (Company)context.getBean("admin");
//    	a1.register();
    	
//    	Desk d1 =(Desk)context.getBean("desk");
//    	System.out.println(d1);
    	
    	Employee e1 =(Employee)context.getBean("employee");
    	e1.register();
    }
}
