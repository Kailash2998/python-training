from django.urls import path
from eshopper import views

urlpatterns = [
    path('',views.home),
    path('registration',views.registration,name='registration'),
    path('login',views.user_login,name='login'),
    path('profile',views.profile,name='profile'),

]