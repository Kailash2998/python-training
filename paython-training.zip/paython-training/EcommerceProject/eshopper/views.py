from django.shortcuts import render,redirect
from .forms import CustomerForm,LoginForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth.hashers import make_password
# Create your views here.
def home(request):
    return render(request,'eshopper/home.html')

def profile(request):
    return render(request,'eshopper/profile.html')

def registration(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            # Redirect to a success page or any other page you want
            print(form.cleaned_data['email'])
            print(form.cleaned_data['password'])
            return redirect('login')
    else:
        form = CustomerForm()
    return render(request, 'eshopper/registration.html', {'form': form})

# def user_login(request):
#     return render(request, 'eshopper/login.html')

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, email=email, password=password)
            print(user)
            if user is not None:
                login(request, user)
                # Redirect to a success page or home page
                return redirect('profile')
            else:
                # Invalid login
                error_message = "Invalid email or password"
    else:
        form = LoginForm()
        error_message = None

    return render(request, 'eshopper/login.html', {'form': form, 'error_message': error_message}) 