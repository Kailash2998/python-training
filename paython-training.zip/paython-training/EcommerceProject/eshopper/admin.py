from django.contrib import admin
from .models import Customer

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('id','email', 'first_name', 'last_name', 'age','password')

# You can customize further by adding more options or overriding methods in the CustomerAdmin class.
