from django import forms
from .models import Customer
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UsernameField

class CustomerForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = Customer
        fields = ['email', 'password', 'first_name', 'last_name', 'age']
        # You can customize widgets or add additional options here if needed
        
class LoginForm(forms.Form):
    email = forms.EmailField(label='Email')
    password = forms.CharField(label='Password', widget=forms.PasswordInput)