class BankAccount:
    def __init__(self, balance=500):
        '''
        used to initializes the attributes
        :param balance: initialize the balance to zero
        balance:float
        '''
        self.balance = balance

    def deposit(self, amount):
        '''
        Prompt the user for input the deposit amount into the bank account.
        :param amount: it is the deposit amount enter by user
        :amount:float
        :return:None
        the function does not return any value explicitly. It prints the deposit amount and add that amount
        into the balance.
        '''
        if amount > 0:
            self.balance += amount
            print(f"successfully Deposited ${amount}")
        else:
            print("Invalid amount for deposit.")

    def withdraw(self, amount):
        '''
         Prompt the user for input the withdraw amount into the bank account.
        :param amount: it is the deposit amount enter by user
        :amount:float
        :return: None
        the function does not return any value explicitly. It prints the withdraw amount and subtract that amount
        from the total balance.
        '''
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"successfully Withdrew ${amount}")
        else:
            print("Insufficient funds.")

    def check_balance(self):
        '''
        function checks the bank balance
        balance:float
        :return: None
        the function does not return any value explicitly. It calculates the total bank balance.
        '''
        print(f"Current balance: ${self.balance}")


if __name__ == "__main__":
    account = BankAccount()
    '''
     create instance of class BankAccount.
     '''
    print("Welcome to the Bank Account Management System!")
    while True:
        print("\nChoose an option:")
        print("1. Deposit")
        print("2. Withdraw")
        print("3. Check Balance")
        print("4. Exit")
        choice = input("Enter your choice (1/2/3/4): ")

        if choice == '1':
            while True:
                try:
                    amount = float(input("Enter the amount to deposit: "))
                    if amount > 0:
                        account.deposit(amount)
                        break
                    else:
                        print("Invalid amount. Please enter a positive number.")
                except ValueError:
                    print("Invalid input. Please enter a number.")
        elif choice == '2':
            while True:
                try:
                    amount = float(input("Enter the amount to withdraw: "))
                    if amount > 0:
                        account.withdraw(amount)
                        break
                    else:
                        print("Invalid amount. Please enter a positive number.")
                except ValueError:
                    print("Invalid input. Please enter a number.")
        elif choice == '3':
            account.check_balance()
        elif choice == '4':
            print("Thank you for using the Bank Account Management System!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, 3, or 4.")
