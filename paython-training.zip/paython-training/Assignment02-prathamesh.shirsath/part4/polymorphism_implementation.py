import math


class Shape:
    def area(self):
        """Method to calculate the area of a shape."""
        pass


class Circle(Shape):
    def __init__(self, radius):
        """
        Initialize Circle object with radius.
        redius:float
        """
        self.radius = radius

    def area(self):
        """
        Calculate the area of the circle.
        pi:float
        radius:float
        :return: area of circle
        """
        return math.pi * self.radius ** 2


class Rectangle(Shape):
    def __init__(self, width, height):
        """
        Initialize Rectangle object with width and height.
        width:float
        height:float
        """
        self.width = width
        self.height = height

    def area(self):
        """
        Calculate the area of the rectangle.
        area:float
        :return :area of rectangle
        """
        return self.width * self.height


if __name__ == "__main__":
    """Create a Circle object with radius 5"""
    circle = Circle(5)
    print("Area of circle: {:.2f}".format(circle.area()))

    """Create a Rectangle object with width 4 and height 6"""
    rectangle = Rectangle(4, 6)
    print("Area of rectangle: {:.2f}".format(rectangle.area()))
