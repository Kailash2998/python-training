def input_tuple(message):
    """
       Prompt the user for input, expecting a tuple of numbers separated by commas.
       :param message: The message to display as a prompt.
       :return: input tuple numbers return by users.
    """
    while True:
        try:
            tuple_input = input(message)
            input_tuple = tuple(map(float, tuple_input.split(',')))
            return input_tuple
        except ValueError:
            print("Invalid input. Please enter numbers separated by commas.")


def combined_tuple(tuple1, tuple2):
    '''
    function combines the two tuples .
    :param tuple1: Input tuple1
    :param tuple2: Input tuple2
    :return:function returns the combined tuple
    '''
    combined_tuple = tuple1 + tuple2
    print("Combined tuple:", combined_tuple)
    return combined_tuple


def convert_to_list(combinedtuple):
    '''
    function converts the combined tuple into the list
    :param combinedtuple: pass the combined tuple as partameter to convert in list.
    :return: function returns the converted list
    '''
    converted_list = list(combinedtuple)
    print("Converted combined tuple to list:", converted_list)
    return converted_list


def input_element(message):
    """Prompt the user to enter an element and validate the input."""
    while True:
        try:
            element = float(input(message))
            return element
        except ValueError:
            print("Invalid input. Please enter a number.")


def find_index_of_element(element):
    '''
    check wheather the input element present in combined tuple or not.
    :param element:  Prompt the user for input element.
    :return: it returns the index of input element
    '''
    try:
        index = combinedtuple.index(element)
        print(f"Element found successfully and Index of element {element}:", index)
    except ValueError:
        print(f"Element {element} not found in the first tuple.")


if __name__ == "__main__":
    '''Take tuples as input from the user'''
    tuple1 = input_tuple("Enter elements of first tuple separated by commas: ")
    tuple2 = input_tuple("Enter elements of second tuple separated by commas: ")

    '''function combines the tuple1 and tuple2'''
    combinedtuple = combined_tuple(tuple1, tuple2)

    '''function converts the combined tuple to list'''
    convert_to_list(combinedtuple)

    ''' 
    Find index of an element in a tuple
    element:float
    '''
    element = input_element("Enter the element to find its index in the combined tuple: ")
    
    find_index_of_element(element)
