def divide_numbers():
    '''
     prompts the user to enter two numbers and performs division.

    :return: none
     The function does not return any value. It prints the result of division if successful
     or an error message if division cannot be performed.
    '''
    try:
        numerator = float(input("Enter the numerator: "))
        denominator = float(input("Enter the denominator: "))
        '''
        numerator:float
        denominator:float
        result:float
        '''
        result = numerator / denominator
        print("Result:", result)
    except ValueError:
        print("Error: Please enter valid numbers.")
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
    except Exception as e:
        print("An unexpected error occurred:", e)


if __name__ == "__main__":
    divide_numbers()
