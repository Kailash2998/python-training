def read_numbers_from_file(file_path):
    '''
    Reads numbers from a file and returns them as a list of floats.
    :param file_path: The path to the input file.
    :return: A list of numbers extracted from the file.
    '''
    try:
        with open(file_path, 'r') as file:
            numbers = [float(line.strip()) for line in file]
            if not numbers:
                raise ValueError("Input file is empty.")
            return numbers
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return []
    except ValueError as e:
        print(f"Error: {e}")
        return []


def calculate_sum(numbers):
    '''
    Calculates the sum of numbers in a list.
    :param numbers: A list of numbers.
    :return: The sum of all numbers in the list.
    '''
    return sum(numbers)


def write_sum_to_file(sum_result, output_file):
    '''
    Writes the sum result to a file.
    :param sum_result: The sum of numbers to write to the file.
    :param output_file: The path to the output file.
    :return: None
    '''
    with open(output_file, 'w') as file:
        file.write(str(sum_result))


def main(input_file, output_file):
    '''
    Main function to read numbers from an input file, calculate their sum, and write the sum to an output file.

    :param input_file: The path to the input file.
    :param output_file: The path to the output file.
    :return: None
    '''
    ''' Read numbers from input file '''
    numbers = read_numbers_from_file(input_file)
    if not numbers:
        return

    ''' Calculate sum of numbers '''
    sum_result = calculate_sum(numbers)

    ''' Write sum to output file '''
    write_sum_to_file(sum_result, output_file)

    ''' Print the sum result '''
    print("Sum result:", sum_result)
    print(f"Sum of numbers has been written to '{output_file}'.")


if __name__ == "__main__":
    input_file = 'input_list_numbers'
    output_file = 'output_sum_result'
    main(input_file, output_file)
