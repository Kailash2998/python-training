import re


def validate_email(email):
    '''
    Function is  validate an email address.
    :param email: The email address to be validated enter by the user.
    :return: None
    The function does not return any value explicitly.It checks the valid email
    '''
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'

    # Check if the email matches the pattern
    if re.match(pattern, email):
        print(f"{email} is a valid email address.")
    else:
        print(f"{email} is not a valid email address.")


def main():
    '''Ask the user to enter an email address'''
    email = input("Enter an email address: ").strip()
    '''
    Strip leading/trailing whitespace
    email:string
    '''

    if email:
        validate_email(email)
    else:
        print("No input provided. Please enter an email address.")


if __name__ == "__main__":
    main()
