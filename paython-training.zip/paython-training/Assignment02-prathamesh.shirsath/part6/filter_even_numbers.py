def filter_even_numbers(numbers):
    '''
    Filters even numbers from a list.
    :param numbers: A list of numbers.
    :return: A list containing only the even numbers from the input list.
    '''
    return list(filter(lambda x: x % 2 == 0, numbers))


def main():
    '''
    Main function to filter a list of numbers to return only even numbers.
    :return: None
    The function does not return any value explicity . It checks even numbers from input numbers.
    '''
    try:
        '''Prompt the user to enter a list of numbers separated by commas'''
        input_numbers = input("Enter a list of numbers separated by commas: ")

        '''Convert the input string into a list of integers'''
        numbers = list(map(int, input_numbers.split(',')))

        '''Filter the list to return only even numbers'''
        even_numbers = filter_even_numbers(numbers)

        '''Print the filtered list of even numbers'''
        print("Even numbers:", even_numbers)

    except ValueError:
        print("Invalid input. Please enter numbers separated by commas.")


if __name__ == "__main__":
    main()
