import csv


def read_csv_and_display(file_path):
    '''
    Reads data from a CSV file and displays it in a formatted manner.
    :param file_path:The path to the CSV file to be read.
    :return:None
    The function does not return any value explicitly.Function prints the csv file data in formatted form,
    also handle invalid file path exception.
    '''
    try:
        with open(file_path, 'r', newline='') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                print("{:<15} {:<15} {:<10}".format(*row))
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")


if __name__ == "__main__":
    ''' Define the path to the CSV file'''
    csv_file_path = 'D:\paython-training\Assignment_sample.csv'

    '''Call the function to read and display data from the CSV file'''
    read_csv_and_display(csv_file_path)
