import os


def list_files(directory):
    """
    List all files in the specified directory.
    :return:function returns the files in directory for valid directory.
    """
    try:
        files = os.listdir(directory)
        return files
    except FileNotFoundError:
        print(f"Directory '{directory}' not found.")
        return []


def print_files(directory, files):
    """
    Print files in the directory.
    :return:None
    The fucntion does not return anything explicitly . It prints the list of files of directory.
    """
    if files:
        print(f"Files in directory '{directory}':")
        for file in files:
            print(file)
    else:
        print("No files found in the specified directory.")


def get_directory_from_user():
    """
    Get directory path from the user.
    :return:The function checks the directory and returns the directory if valid.
    """
    while True:
        directory = input("Enter the directory path: ")
        if os.path.isdir(directory):
            return directory
        else:
            print("Invalid directory path. Please enter a valid directory path.")


if __name__ == "__main__":
    directory = get_directory_from_user()
    files = list_files(directory)
    print_files(directory, files)
