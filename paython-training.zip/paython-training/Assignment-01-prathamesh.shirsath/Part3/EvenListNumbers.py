#empty list declaration
Input_List = []
Even_List = []

n = int(input("enter total number of elements in list :"))

#add elements in list
for i in range(n):
    element = int(input("enter number:"))
    Input_List.append(element)

#add the even numbers in Even_List
for num in Input_List:
    if num % 2 == 0:
        Even_List.append(num)
        
print("Input list:",Input_List)
print("Even list:",Even_List)