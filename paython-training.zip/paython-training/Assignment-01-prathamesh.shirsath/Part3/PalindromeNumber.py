input_num = int(input("enter number:"))
temp = input_num
reverse_num=0

#reverse the input_num
while input_num > 0:
    digit = input_num % 10
    reverse_num = reverse_num *10+digit
    input_num//=10
    
#Check wheather number is palindrome or not 
if(temp==reverse_num):
    print(temp,"is palindrome number")
else:
    print(temp,"is not palindrome number")
