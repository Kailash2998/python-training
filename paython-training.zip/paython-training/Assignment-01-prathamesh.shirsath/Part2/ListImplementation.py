#take student names seprated by commma
student_names = input("Enter the names of the students: ").split(',')

total_length = sum(len(name) for name in student_names)

#count average length of names in list 
avergae_length = total_length / len(student_names)

print("Student name list :",student_names)
print("Total number of students:",len(student_names))
print("Total length of student names",total_length)
print("Average length of student names:",avergae_length)

