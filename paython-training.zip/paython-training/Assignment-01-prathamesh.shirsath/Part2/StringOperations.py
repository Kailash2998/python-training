input_string = input("enter a string:") 

#python built-in method used swapcase()
converted_string = input_string.swapcase();

print("Input String :",input_string)
print("Converted String :",converted_string)
