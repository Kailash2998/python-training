num1 = float(input("enter first number :- "))
num2 = float(input("enter second number :-"))

addition = num1+num2
substraction = num1-num2
multiplication = num1*num2
division = num1/num2

print("Two number addition :",addition,"\n Two number substraction :",substraction,"\n Two number multiplication :",multiplication,"\n Two number division:",division)