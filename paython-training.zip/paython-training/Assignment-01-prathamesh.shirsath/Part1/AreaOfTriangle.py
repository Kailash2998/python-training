b = float(input("enter base of traingle"))
h = float(input("enter height of traingle"))

area = 0.5*b*h

print("area of traingle is:",area)