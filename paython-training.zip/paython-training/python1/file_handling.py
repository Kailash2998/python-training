'''file read mode'''
f1=open("file1.txt",'r') #f1 is the object
data=f1.read()
print(data)

'''file write operation'''
f2=open("file2.txt",'w')
f2.write("jay hanuman dada...!")

'''file r+ mode'''
#f3=open("file3.txt","x")
f3=open("file3.txt","r+")
f3.write("kanbai mata...!")
print(f3.read())

'''file w+ mode'''
f4=open("file4.txt","w+")
f4.write("mhalsa mata prassann")
f4.seek(0)
print(f4.read())

'''file a mode'''
f5=open("file5.txt","a")
f5.write("jay munjjoba...!")
f5.write("saptarhrungi mata ki jay ho ...!")
#print(f5.read()) not supported the read operation in a mode(append)


f6=open("D:\paython-training/demo_code.txt","a")
print(f6.write(""))

