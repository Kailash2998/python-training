#function display the questions
def display_question(question_data):
    print("\n" + question_data["question"])
    for option in question_data["options"]:
        print(option)

#function checks the answear validation
def get_user_answer():
    while True:
        user_answer = input("Your answer (Enter A, B, C, or D): ").upper()
        if user_answer in ["A", "B", "C", "D"]:
            return user_answer
        else:
            print("Invalid input. Please enter A, B, C, or D.")

#function checks the user answear
def check_answer(question_data, user_answer):
    if user_answer == question_data["answer"]:
        print("Correct!")
        return 1
    else:
        print("Incorrect. The correct answer is option:", question_data["answer"])
        return 0

questions = [
    {
        "question": "What is 5 + 5?",
        "options": ["A. 10", "B. 15", "C. 20", "D. 25"],
        "answer": "A"
    },
    {
        "question": "What is the capital of Japan?",
        "options": ["A. Tokyo", "B. Beijing", "C. Seoul", "D. Bangkok"],
        "answer": "A"
    },
    {
        "question": "Who wrote 'Romeo and Juliet'?",
        "options": ["A. William Shakespeare", "B. Charles Dickens", "C. Jane Austen", "D. Mark Twain"],
        "answer": "A"
    },
    {
        "question": "What is the largest ocean on Earth?",
        "options": ["A. Pacific Ocean", "B. Atlantic Ocean", "C. Indian Ocean", "D. Arctic Ocean"],
        "answer": "A"
    }
]

score = 0
print("Welcome to the Quiz Game!")

# loop iterates over the questions
for question_data in questions:
    display_question(question_data)
    user_answer = get_user_answer()
    score += check_answer(question_data, user_answer)
    
#output
print("\nQuiz complete!")
print("Your score:", score, "out of", len(questions))
