# Input validation for year
while True:
    try:
        year = int(input("Enter Year: "))
        break
    except ValueError:
        print("Error: Please enter a valid year.")

#check wheather input year is leap year or not
def is_leap_year(year):
    if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0):
        return True
    else:
        return False

# Checking leap year status
if is_leap_year(year):
    print(year, "is a leap year.")
else:
    print(year, "is not a leap year.")
