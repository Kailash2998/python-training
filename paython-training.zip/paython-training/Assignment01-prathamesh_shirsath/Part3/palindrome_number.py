# Input validation for number
while True:
    try:
        input_num = int(input("Enter a number: "))
        break
    except ValueError:
        print("Error: Please enter a valid number.")

#palindrome number logic
def is_palindrome_number(num):
    temp = num
    reverse_num = 0
    while num > 0:
        digit = num % 10
        reverse_num = reverse_num * 10 + digit
        num //= 10

    # Check if the original number is equal to its reverse
    if temp == reverse_num:
        return True
    else:
        return False

# Check whether the number is a palindrome
if is_palindrome_number(input_num):
    print(input_num, "is a palindrome number.")
else:
    print(input_num, "is not a palindrome number.")
