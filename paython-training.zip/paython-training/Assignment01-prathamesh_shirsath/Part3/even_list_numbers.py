# Empty list declaration
input_list = []
even_list = []

# Input validation
while True:
    try:
        n = int(input("Enter the total number of elements in the list: "))
        if n > 0:
            break
        else:
            print("Error: Please enter a positive integer.")
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer.")

#add elements in list
def take_input_list(n):
    input_list = []
    for i in range(n):
        while True:
            try:
                element = int(input("Enter element {}: ".format(i + 1)))
                input_list.append(element)
                break
            except ValueError:
                print("Error: Invalid input. Please enter a valid integer.")
    return input_list

#add even elements in list
def find_even_numbers(input_list):
    even_list = [num for num in input_list if num % 2 == 0]
    return even_list

#function calling
input_list = take_input_list(n)
even_list = find_even_numbers(input_list)

# Output
print("\nInput list:", input_list)
print("Even list:", even_list)
