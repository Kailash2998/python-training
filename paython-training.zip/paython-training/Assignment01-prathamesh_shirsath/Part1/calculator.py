#input validation
while True:
    try:
        num1 = float(input("Enter the first number: "))
        num2 = float(input("Enter the second number: "))
        if num2 == 0:
            raise ValueError("The second number cannot be zero.")
        break
    except ValueError as ve:
        print("Invalid input. Please enter valid numerical values.")

#arithmetic operations
addition = num1 + num2
substraction = num1 - num2
multiplication = num1 * num2
division = num1 / num2

#output
print("\nResults:")
print("  Addition: {:.2f}".format(addition))
print("  Subtraction: {:.2f}".format(substraction))
print("  Multiplication: {:.2f}".format(multiplication))
print("  Division: {:.2f}".format(division))
