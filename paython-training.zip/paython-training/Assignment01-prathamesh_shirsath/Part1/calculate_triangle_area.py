#input validation
try:
    base = float(input("Enter the base of the triangle: "))
    height = float(input("Enter the height of the triangle: "))
    if base > 0 and height > 0:
        #calculate the area of traingle
        area = 0.5 * base * height
        print("  Area of the triangle is: {:.2f}".format(area))
    else:
        print("Enter non zero height and base input")
except ValueError:
    print("Invalid input. Please enter valid numerical values for base and height.")
