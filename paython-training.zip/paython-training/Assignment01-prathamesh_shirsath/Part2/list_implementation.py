# Take student names separated by comma
student_names = input("Enter the names of the students (separated by comma): ")

#check if list is empty
if not student_names:
    print("Error: No names entered.")
    exit()

# Split the input string by comma to get a list of names
student_names = student_names.split(',')

# Filter out any empty strings from the input
student_names = [name.strip() for name in student_names if name.strip()]

# Input Validation
if not student_names:
    print("Error: No valid names entered.")
    exit()

#calculate total length
total_length = sum(len(name) for name in student_names)

#calculate average length of names in list 
average_length = total_length / len(student_names)

print("\nResult:")
print("Student name list :",student_names)
print(f"  Total number of students: {len(student_names)}")
print(f"  Total length of student names: {total_length}")
print(f"  Average length of student names: {average_length:.2f}")
