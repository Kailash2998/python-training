#input validation
def is_valid_string(input_string):
    for char in input_string:
        if char.isalpha():
            return True
    return False

#case swaping
def swap_case(input_string):
    swapped_string = ''
    for char in input_string:
        if char.islower():
            swapped_string += char.upper()
        elif char.isupper():
            swapped_string += char.lower()
        else:
            swapped_string += char
    return swapped_string

# Input Validation
while True:
    input_string = input("Enter a string: ").strip()
    if input_string and is_valid_string(input_string):
        break
    else:
        print("Error: Please enter a valid string containing at least one alphabet character.")

# Case swapping
converted_string = swap_case(input_string)

# Output
print("\nInput String: ", input_string)
print("Converted String: ", converted_string)
