import { Component, EventEmitter, Input, Output } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { ToastrService } from 'ngx-toastr'
import { TempleService } from '../temples-list/temple-service.service'
@Component({
  selector: 'app-add-edit-temples',
  templateUrl: './add-edit-temples.component.html',
  styleUrls: ['./add-edit-temples.component.scss']
})
export class AddEditTemplesComponent {
  @Input() temple: any
  @Output() close = new EventEmitter()

  /* The code `public templeForm = new FormGroup({ ... })` is creating an instance of the `FormGroup`
  class. */
  public templeForm = new FormGroup({
    firstName: new FormControl("",[Validators.required,Validators.maxLength(20),Validators.minLength(2),Validators.pattern(/^[A-Za-z]+$/)]),
    lastName: new FormControl("",[Validators.required,Validators.maxLength(10),Validators.minLength(2),Validators.pattern(/^[A-Za-z]+$/)]),
    age: new FormControl('', [Validators.required]),
    queue: new FormControl('', [Validators.required]),
    gender: new FormControl('', [Validators.required]),
    date: new FormControl('', [Validators.required])
  })


  constructor (
    private TempleService: TempleService,
    private toastrService: ToastrService
  ) {}

  /**
   * The ngOnInit function checks if the temple object exists and updates the templeForm with its
   * values.
   */
  ngOnInit () {
    if (this.temple) {
      this.templeForm.patchValue(this.temple)
    }
  }

  
  /* The line `public currentDate: any = new Date()` is initializing a public variable `currentDate`
   */
  public currentDate: any = new Date()

  /**
   * The function "onClose" emits a "close" event.
   */
  public onClose (): void {
    this.close.emit()
  }

  /**
   * The save function checks if a temple exists and either adds a new temple or updates an existing
   * one based on the payload.
   */
  public save (): void {
    let payload = this.assignValueToModel()
    if (!this.temple) {
      this.addTemple(payload)
    } else {
      this.updateTemple(payload)
    }
  }

 /**
  * The addTemple function adds a temple record using the TempleService and displays a success message
  */
  private addTemple (payload: any): void {
    this.TempleService.addTemple(payload).subscribe(
      (response: any) => {
        this.toastrService.success(
          'devotees record added successfully',
          'Success'
        )
        this.onClose()
      },
      (error: any) => {
        this.toastrService.error('Error adding devotees record', 'Error')
      }
    )
  }

  /**
   * The function `updateTemple` updates the temple's devotees list and displays a success message if
   * successful, or an error message if there is an error.
   */
  private updateTemple (payload: any): void {
    this.TempleService.updateTemple(payload).subscribe(
      (response: any) => {
        this.toastrService.success(
          'Devotees list updated succefully',
          'Success'
        )
        this.onClose()
      },
      (error: any) => {
        this.toastrService.error('Error to update devotees record', 'Error')
      }
    )
  }

  private assignValueToModel (): any {
    let temple = {
      id: this.temple ? this.temple.id : 0,
      firstName: this.templeForm.get('firstName')?.value,
      lastName: this.templeForm.get('lastName')?.value,
      age: this.templeForm.get('age')?.value,
      queue: this.templeForm.get('queue')?.value,
      gender: this.templeForm.get('gender')?.value,
      date: this.templeForm.get('date')?.value
    }
    return temple
  }

  
  /**
   * The function checks if a form control is invalid, has errors, and has been interacted with.
   */
  public checkIfControlValid (controlName: any): boolean {
    return this.templeForm.get(controlName)?.invalid &&
      this.templeForm.get(controlName)?.errors &&
      (this.templeForm.get(controlName)?.dirty ||
        this.templeForm.get(controlName)?.touched)
      ? true
      : false
  }

  /**
   * The function "checkControlHasError" checks if a specific control in a form has a specific error.
   */
  public checkControlHasError (controlName: any, error: any): boolean {
    return this.templeForm.get(controlName)?.hasError(error) ? true : false
  }
}
