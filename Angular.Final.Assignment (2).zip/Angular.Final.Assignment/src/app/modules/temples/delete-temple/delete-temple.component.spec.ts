import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteTempleComponent } from './delete-temple.component';

describe('DeleteTempleComponent', () => {
  let component: DeleteTempleComponent;
  let fixture: ComponentFixture<DeleteTempleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteTempleComponent]
    });
    fixture = TestBed.createComponent(DeleteTempleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
