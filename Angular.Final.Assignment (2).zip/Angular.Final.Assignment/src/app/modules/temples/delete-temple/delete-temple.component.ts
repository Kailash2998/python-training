
import { Component,EventEmitter,Output,Input } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {TempleService} from '../temples-list/temple-service.service'

@Component({
  selector: 'app-delete-temple',
  templateUrl: './delete-temple.component.html',
  styleUrls: ['./delete-temple.component.scss']
})

export class DeleteTempleComponent {
  @Input() temple: any;
  @Output() close = new EventEmitter();

  constructor(private TempleService : TempleService,
  private toastrService : ToastrService){} 

  /**
   * The function "onClose" emits a "close" event.
   */
  public onClose(): void{
    this.close.emit(); 
  }

  /**
   * The onDelete function calls the deleteTemple function with the temple parameter.
   */
  public onDelete(): void{
    this.deleteTemple(this.temple)
  }

  /**
   * The function `deleteTemple` is a private method that deletes a temple record and displays a
   * success message.
   */
  private deleteTemple(temple: any): void{
    this.TempleService.deleteTemple(temple).subscribe((response: any) => {
      this.toastrService.success("devotees record deleted successfully","Success");
      this.onClose();
    },(error: any) => {
      this.toastrService.error("Error to delete devotees record","Error")
    });
  }
}
