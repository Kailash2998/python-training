import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})

//create TempleService
export class TempleService {
  public baseUrl = 'http://localhost:3000/temples';

  constructor(private http: HttpClient) {}

  public getTemples(): any {
    return this.http.get('http://localhost:3000/temples')
  }

  public addTemple(temple:any):any{
    return this.http.post('http://localhost:3000/temples',temple);
  }

  public updateTemple(temple:any):any{
    return this.http.put(`http://localhost:3000/temples/${temple.id}`,temple);
  }

  public deleteTemple(temple:any):any{
    return this.http.delete(`http://localhost:3000/temples/${temple.id}`);
  }

}
