import { Component } from '@angular/core';
import {TempleService} from '../temples-list/temple-service.service'
import { ToastrService } from 'ngx-toastr';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddEditTemplesComponent } from '../add-edit-temples/add-edit-temples.component';
import { DeleteTempleComponent } from '../delete-temple/delete-temple.component';

@Component({
  selector: 'app-temples-list',
  templateUrl: './temples-list.component.html',
  styleUrls: ['./temples-list.component.scss']
})

export class TemplesListComponent {
  public totalCount: number = 0;
  public temples: any[] = [];
  public addEditTempleModal !: BsModalRef;
  public deleteTempleModal !: BsModalRef;

  constructor(private productService: TempleService,
    private toastrService: ToastrService,
    private modalService: BsModalService) {}

  /**
   * The ngOnInit function is used to load temples when the component is initialized.
   */
  ngOnInit(){
    this.loadTemples();
  }

  /**
   * The function "loadTemples" retrieves a list of temples from a service and assigns it to a
   * variable, while also updating a total count variable.
   */
  private loadTemples(): void{
    this.productService.getTemples().subscribe((response: any) => {
      this.temples = response;
      this.totalCount = this.temples.length;
    },(error: any) => {
      this.toastrService.error("Error loading devotees list","Error")
    })
  }

  //for add-edit list
  /**
   * The function opens a modal window for adding or editing a temple, and updates the list of temples
   * after the modal is closed.
   */
  openAddEditTempleModal(temple: any = null): void {
    this.addEditTempleModal = this.modalService.show(AddEditTemplesComponent,{
      initialState: { temple: temple}, class:"modal-lg",
      ignoreBackdropClick: true
    });

    this.addEditTempleModal.content.close.subscribe(() => {
      this.addEditTempleModal.hide();
      this.loadTemples();
    })
  }

 /**
  * The function `openDeleteTempleModal` opens a modal window to delete a temple and reloads the list
  * of temples after the deletion.
  */
  openDeleteTempleModal(temple: any): void{
    this.deleteTempleModal = this.modalService.show(DeleteTempleComponent,{
      initialState: { temple: temple}, 
      class:"modal-sm",
      ignoreBackdropClick: true
    });

    this.deleteTempleModal.content.close.subscribe(() => {
      this.deleteTempleModal.hide();
      this.loadTemples();
    })
  }
}
