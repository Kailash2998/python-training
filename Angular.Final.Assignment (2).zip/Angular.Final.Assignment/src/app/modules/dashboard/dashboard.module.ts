import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap/modal';
import { RouterModule, Routes} from '@angular/router';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { AdminComponent } from './components/admin/admin.component';
import { AddEditTemplesComponent } from '../temples/add-edit-temples/add-edit-temples.component';
import { DeleteTempleComponent } from '../temples/delete-temple/delete-temple.component';
import { TemplesListComponent } from '../temples/temples-list/temples-list.component';

const routes : Routes = [
  { path: '',
    component: AdminComponent,
    children: [
      { path:'home', component: HomeComponent},
      {path:'temples', component:TemplesListComponent},
      {path : '',redirectTo:'/admin/home',pathMatch:'full'}
    ]
  },
]

@NgModule({
  declarations: [
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    AdminComponent,
    AddEditTemplesComponent,
    DeleteTempleComponent,
    TemplesListComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule, 
    ModalModule.forRoot(),
    NgxDatatableModule,
    ReactiveFormsModule,
    FormsModule,
    ToastrModule.forRoot(),
  ],
  exports: [RouterModule]
})
export class DashboardModule { }
