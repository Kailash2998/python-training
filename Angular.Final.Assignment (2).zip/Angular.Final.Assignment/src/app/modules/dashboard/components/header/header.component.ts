import { AuthService } from 'src/app/shared/helper/auth.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  constructor(private auth: AuthService) {}

  ngOnInit(): void {}
  
  /**
   * The `logout` function calls the `logout` method of the `auth` object.
   */
  logout(): void {
    this.auth.logout();
  }
} 
